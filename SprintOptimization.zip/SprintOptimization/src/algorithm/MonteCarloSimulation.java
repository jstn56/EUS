package algorithm;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Map;
import java.util.TreeMap;

import ilog.concert.IloException;
import model.Competence;
import model.Employee;
import model.Sprint;
import model.UserStory;
import ui.ScrumApp.SimulationProgressListener;

// Klasse zur Durchführung einer Monte-Carlo-Simulation für die Zuweisung von User Stories zu Sprints
public class MonteCarloSimulation {

    // Instanzvariablen für die Simulation
    private final UserStoryAssignment userStoryAssignment; // Zuweisungslogik für User Stories
    private final List<UserStory> originalUserStories; // Liste der ursprünglichen User Stories
    private final List<Employee> originalEmployees; // Liste der ursprünglichen Mitarbeiter
    private final int sprintCapacity; // Maximale Punktzahl, die ein Sprint haben kann
    private final int sprintTime; // Zeitdauer eines Sprints
    private final Random random; // Zufallsgenerator für die Simulation
    private final List<Competence> allCompetencies;
    
    /**
     * Konstruktor der MonteCarloSimulation-Klasse.
     * Initialisiert alle erforderlichen Instanzvariablen für die Simulation.
     * 
     * @param userStoryAssignment Eine Instanz von UserStoryAssignment zur Zuweisung von User Stories zu Sprints.
     * @param userStories Eine Liste der ursprünglichen User Stories, die in der Simulation verwendet werden.
     * @param employees Eine Liste der Mitarbeiter, die für die Zuweisung von User Stories in den Sprints verwendet werden.
     * @param sprintCapacity Die maximale Punktzahl, die ein Sprint haben kann, basierend auf der Story-Komplexität.
     * @param sprintTime Die Zeitdauer eines Sprints in Wochen.
     * @param allCompetencies Eine Liste aller verfügbaren Kompetenzen, die in der Simulation verwendet werden.
     */
    public MonteCarloSimulation(UserStoryAssignment userStoryAssignment, List<UserStory> userStories, List<Employee> employees, int sprintCapacity, int sprintTime, List<Competence> allCompetencies) {
        this.userStoryAssignment = userStoryAssignment;
        this.originalUserStories = userStories;
        this.originalEmployees = employees;
        this.sprintCapacity = sprintCapacity;
        this.sprintTime = sprintTime;
        this.allCompetencies = allCompetencies;
        this.random = new Random();
    }

    /**
     * Führt eine Monte-Carlo-Simulation mit gegebenen Parametern durch.
     * 
     * @param simulations Anzahl der Durchläufe der Simulation.
     * @param minChange Negative Änderung der Story Points pro User Story.
     * @param maxChange Positive Änderung der Story Points pro User Story.
     * @param maxNewUserStories Maximale Anzahl neuer User Stories, die pro Simulation hinzugefügt werden können.
     * @param minNew Minimaler Wert der Komplexität für neue User Stories.
     * @param maxNew Maximaler Wert der Komplexität für neue User Stories.
     * @param includeChangingRequirements True, wenn die Simulation wechselnde Anforderungen berücksichtigen soll.
     * @param includeNewRequirements True, wenn die Simulation neue Anforderungen berücksichtigen soll.
     * @param includeEmployeeResignations True, wenn die Simulation Kündigungen von Mitarbeitern berücksichtigen soll.
     * @param progressListener Listener, der den Fortschritt der Simulation aktualisiert.
     * @return Ein Histogramm, das die Anzahl der Wochen für den Abschluss der Sprints in den verschiedenen Szenarien anzeigt.
     * @throws IloException Wird geworfen, wenn bei der Optimierung ein Problem auftritt.
     */
    public Map<Integer, Integer> simulate(int simulations, int minChange, int maxChange, int maxNewUserStories, int minNew, int maxNew,
            boolean includeChangingRequirements, boolean includeNewRequirements, boolean includeEmployeeResignations, SimulationProgressListener progressListener) throws IloException {
        Map<Integer, Integer> histogram = new TreeMap<>(); // Histogramm zur Speicherung der Ergebnisse
        
        // Erstellung einer tiefen Kopie der ursprünglichen User Stories, damit sich z.B. die Komplexität nicht bei jeder Simulation aufsummiert und immer vom ursprünglichen Wert ausgegangen wird
        List<UserStory> originalUserStoriesCopy = deepCopyUserStoriesList(originalUserStories);
        
        
        // Durchführung der angegebenen Anzahl an Simulationen
        for (int i = 0; i < simulations; i++) {        	
        	// Erstellung der Kopien zu Beginn jedes Simulationsdurchlaufs
            List<UserStory> simulatedUserStories = deepCopyUserStoriesList(originalUserStoriesCopy);
            List<Employee> simulatedEmployees = new ArrayList<>(originalEmployees);
            
            // Wechselnde Anforderungen, nur wenn Checkbox aktiviert ist
            if (includeChangingRequirements) {
                for (UserStory story : simulatedUserStories) {
                    int change = minChange + random.nextInt(maxChange - minChange + 1);
                    story.adjustComplexity(change); // Anpassung der Komplexität jeder User Story
                }
            }
            
            // Neue Anforderungen, nur wenn Checkbox aktiviert ist
            if (includeNewRequirements) {
                int numberOfNewStories = 1 + random.nextInt(maxNewUserStories); // Zufällige Anzahl neuer User Stories
                
                // Erstellung neuer User Stories basierend auf den gegebenen Parametern
                for (int j = 0; j < numberOfNewStories; j++) {
                	int newUtility = random.nextInt(101);
                	int newStoryPoints = minNew + random.nextInt(maxNew - minNew + 1);
                    double criticalRisk = 1.0 + random.nextDouble(); // Zufälliges kritisches Risiko
                    double uncertaintyRisk = 1.0 + random.nextDouble(); // Zufälliges Unsicherheitsrisiko
                    UserStory newUserStory = new UserStory("New UserStory " + (j+1), "Generated by simulation", 
                    		newUtility, newStoryPoints, criticalRisk, uncertaintyRisk);
                    newUserStory.addRequiredCompetence(allCompetencies.get(random.nextInt(allCompetencies.size())));
                    // Hinzufügen einer zufälligen Kompetenz
                    simulatedUserStories.add(newUserStory); // Hinzufügen der neuen User Story zur Liste
                }
            }

            // Kündigung eines Mitarbeiters, nur wenn Checkbox aktiviert ist
            if (includeEmployeeResignations) {
                int employeeIndex = random.nextInt(simulatedEmployees.size()); // Zufällige Auswahl eines Mitarbeiters
                simulatedEmployees.remove(employeeIndex); // Entfernen des Mitarbeiters aus der Liste
            }

            // Zuweisung der User Stories zu Sprints und Berechnung der benötigten Wochen
            List<Sprint> sprints =  userStoryAssignment.assignUserStoriesToSprintsCPLEX(simulatedUserStories, simulatedEmployees, sprintCapacity, sprintTime, false);
            int weeks = sprints.size() * sprints.get(0).getTime(); // Berechnung der Gesamtzeit in Wochen

            // Aktualisierung des Histogramms mit der Anzahl der benötigten Wochen
            histogram.put(weeks, histogram.getOrDefault(weeks, 0) + 1);
            
            // Aktualisieren des Fortschritts über die progressBar im UI
            if (progressListener != null) {
                int progress = (i + 1) * simulations / simulations;
                progressListener.onProgressUpdate(progress);
            }
        }

        return histogram; // Rückgabe des Histogramms mit den Simulationsergebnissen
    }

    /**
     * Erstellt eine tiefe Kopie einer Liste von User Stories.
     * Jedes Element in der Liste wird kopiert, so dass Änderungen an den kopierten Objekten
     * die ursprünglichen Objekte nicht beeinflussen.
     *
     * @param userStories Die Liste der User Stories, die kopiert werden soll.
     * @return Eine neue Liste mit Kopien der User Stories.
     */
	private List<UserStory> deepCopyUserStoriesList(List<UserStory> userStories) {
		 List<UserStory> copy = new ArrayList<>();
		    for (UserStory story : userStories) {
		        copy.add(new UserStory(story));
		    }
		    return copy;
	}
}