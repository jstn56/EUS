package algorithm;

import ilog.concert.*;
import ilog.cplex.*;
import model.*;

import java.util.ArrayList;
import java.util.List;

public class UserStoryAssignment {
	/**
	 * Hauptmethode zur Zuweisung von User Stories zu Sprints unter Verwendung des IBM CPLEX Optimizers.
	 * 
	 * @param userStories Die Liste der User Stories, die den Sprints zugeordnet werden sollen.
	 * @param employees Die Liste der Mitarbeiter, die an den Sprints teilnehmen.
	 * @param sprintCapacity Die maximale Kapazität eines Sprints.
	 * @param sprintTime Die Dauer eines Sprints in Wochen.
	 * @param print Flag, das bestimmt, ob Details der Zuordnung gedruckt werden sollen.
	 * @return Eine Liste von Sprints mit den zugeordneten User Stories.
	 * @throws IloException Wenn bei der Verwendung des CPLEX Optimizers ein Fehler auftritt.
	 */
    public List<Sprint> assignUserStoriesToSprintsCPLEX(List<UserStory> userStories, List<Employee> employees, int sprintCapacity, int sprintTime, boolean print) throws IloException {
    	// Initialisierung der Variablen für das Optimierungsmodell
    	Variables vars = new Variables(userStories, employees);
    	// Erstellung einer Instanz von IloCplex, die für die Optimierung verwendet wird
        IloCplex cplex = new IloCplex();        
        // Aufbau des Optimierungsmodells
        createCplexModel(cplex, vars, userStories, employees, sprintCapacity);
        // Definition der Zielfunktion für das Modell
        defineObjectiveFunction(cplex, vars, userStories, sprintCapacity);
        // Hinzufügen der notwendigen Beschränkungen zum Modell
        addConstraints(cplex, vars, userStories, employees, sprintCapacity);
        // Lösen des Modells und Extrahieren der Ergebnisse
        return solveModel(cplex, vars, userStories, employees, sprintCapacity, sprintTime, print);
    }
    
    /**
     * Interne Klasse zur Verwaltung der Optimierungsvariablen im CPLEX Modell.
     * Diese Klasse definiert die notwendigen Variablen für die Optimierungsaufgabe.
     */
    private static class Variables {
        int N, M, T;
        // xi: Ein 3-dimensionales Array von binären Entscheidungsvariablen. 
        // xi[t][i][m] ist 1, wenn die User Story i im Sprint t von Mitarbeiter m bearbeitet wird.
        IloIntVar[][][] xi;
        // sprintUsage: Ein Array von Entscheidungsvariablen, das die Gesamtauslastung jedes Sprints angibt.
        IloIntVar[] sprintUsage;
        
        /**
         * Konstruktor, der die Größe der Variablenfelder basierend auf der Anzahl der User Stories und Mitarbeiter festlegt.
         *
         * @param userStories Liste der User Stories, die den Sprints zugeordnet werden sollen.
         * @param employees Liste der Mitarbeiter, die an den Sprints teilnehmen.
         */
        public Variables(List<UserStory> userStories, List<Employee> employees) {
            this.N = userStories.size();
            this.M = employees.size();
            this.T = N; // oder eine andere geeignete Berechnung für die Anzahl der Sprints
        }
    }
    
    /**
     * Erstellt das Optimierungsmodell in IBM CPLEX.
     * Definiert die Variablen und deren Dimensionen, die für die Zuweisung der User Stories zu Sprints benötigt werden.
     *
     * @param cplex Die Instanz von IloCplex, die für die Optimierung verwendet wird.
     * @param vars Die Instanz der internen Klasse Variables, die die Variablen des Modells enthält.
     * @param userStories Die Liste der User Stories, die den Sprints zugeordnet werden sollen.
     * @param employees Die Liste der Mitarbeiter, die an den Sprints teilnehmen.
     * @param sprintCapacity Die maximale Kapazität eines Sprints.
     * @throws IloException Wenn bei der Modellerstellung ein Fehler auftritt.
     */
    private void createCplexModel(IloCplex cplex, Variables vars, List<UserStory> userStories, List<Employee> employees, 
    		int sprintCapacity) throws IloException {
        // Initialisierung der Entscheidungsvariablen für die Zuordnung von User Stories zu Sprints und Mitarbeitern
    	vars.xi = new IloIntVar[vars.T][vars.N][vars.M];
        // Initialisierung der Variablen für die Sprintauslastung
    	vars.sprintUsage = new IloIntVar[vars.T];
    	
        // Für jeden Sprint, jede User Story und jeden Mitarbeiter eine binäre Variable erstellen
        for (int t = 0; t < vars.T; t++) {
            vars.sprintUsage[t] = cplex.intVar(0, sprintCapacity); // Sprintauslastungsvariable
            for (int i = 0; i < vars.N; i++) {
                vars.xi[t][i] = cplex.boolVarArray(vars.M); // Binäre Variablen für die Zuordnung
            }
        }
    }
    
    /**
     * Definiert die Zielfunktion im Optimierungsmodell.
     * Die Funktion zielt darauf ab, den Gesamtnutzen der User Stories zu maximieren,
     * gewichtet mit dem kritischen Risiko, und die Sprintauslastung zu berücksichtigen.
     * 
     * @param cplex Die Instanz von IloCplex, die für die Optimierung verwendet wird.
     * @param vars Die Instanz der internen Klasse Variables, die die Variablen des Modells enthält.
     * @param userStories Die Liste der User Stories, die den Sprints zugeordnet werden sollen.
     * @param sprintCapacity Die maximale Kapazität eines Sprints.
     * @throws IloException Wenn bei der Definition der Zielfunktion ein Fehler auftritt.
     */
    private void defineObjectiveFunction(IloCplex cplex, Variables vars, List<UserStory> userStories, int sprintCapacity) 
    		throws IloException {
        // Erstellen einer linearen numerischen Ausdruck für die Zielfunktion
    	IloLinearNumExpr objective = cplex.linearNumExpr();
        
    	// Durchlaufen aller Sprints, User Stories und Mitarbeiter, um die Zielfunktion zu definieren
        for (int t = 0; t < vars.T; t++) {
            for (int i = 0; i < vars.N; i++) {
                for (int m = 0; m < vars.M; m++) {
                	// Hinzufügen des Nutzens der User Story multipliziert mit dem kritischen Risiko
                    // zur Zielfunktion, falls die User Story im Sprint bearbeitet wird
                    objective.addTerm(userStories.get(i).getUtility() * userStories.get(i).getCritical_risk(), vars.xi[t][i][m]);
                }
            }
            // Hinzufügen eines Terms zur Zielfunktion, der die Sprintauslastung berücksichtigt
            objective.addTerm(1.0 / sprintCapacity, vars.sprintUsage[t]);
        }
        // Instruktion an CPLEX, die Zielfunktion zu maximieren
        cplex.addMaximize(objective);
    }
    
    /**
     * Fügt die Nebenbedingungen zum Optimierungsmodell hinzu. 
     * Diese Nebenbedingungen stellen sicher, dass die Lösung des Optimierungsproblems praktikabel ist.
     *
     * @param cplex Die Instanz von IloCplex, die für die Optimierung verwendet wird.
     * @param vars Die Instanz der internen Klasse Variables, die die Variablen des Modells enthält.
     * @param userStories Die Liste der User Stories, die den Sprints zugeordnet werden sollen.
     * @param employees Die Liste der Mitarbeiter, die an den Sprints teilnehmen.
     * @param sprintCapacity Die maximale Kapazität eines Sprints (z.B. maximale Story Points).
     * @throws IloException Wenn beim Hinzufügen der Nebenbedingungen ein Fehler auftritt.
     */
    private void addConstraints(IloCplex cplex, Variables vars, List<UserStory> userStories, List<Employee> employees, int sprintCapacity) throws IloException {
    	
    	// Nebenbedingung 1: Gesamtkomplexität der User Stories in einem Sprint darf sprintCapacity nicht überschreiten
        for (int t = 0; t < vars.T; t++) {
            IloLinearNumExpr complexityExpr = cplex.linearNumExpr();
            for (int i = 0; i < vars.N; i++) {
                for (int m = 0; m < vars.M; m++) {
                    complexityExpr.addTerm(userStories.get(i).getComplexity() * userStories.get(i).
                    		getUncertainty_risk(), vars.xi[t][i][m]);
                }
            }
            cplex.addLe(complexityExpr, sprintCapacity);
        }
        
        // Nebenbedingung 2: Jede User Story darf maximal in einem Sprint bearbeitet werden
        for (int i = 0; i < vars.N; i++) {
            IloLinearNumExpr storyExpr = cplex.linearNumExpr();
            for (int t = 0; t < vars.T; t++) {
                for (int m = 0; m < vars.M; m++) {
                    storyExpr.addTerm(1.0, vars.xi[t][i][m]);
                }
            }
            cplex.addLe(storyExpr, 1);
        }

        // Nebenbedingung 3: Jeder Mitarbeiter darf in einem Sprint maximal an einer Story arbeiten
        for (int m = 0; m < vars.M; m++) {
            for (int t = 0; t < vars.T; t++) {
                IloLinearNumExpr employeeExpr = cplex.linearNumExpr();
                for (int i = 0; i < vars.N; i++) {
                    employeeExpr.addTerm(1.0, vars.xi[t][i][m]);
                }
                cplex.addLe(employeeExpr, 1);
            }
        }
        

        // Nebenbedingung 4: Mitarbeiter darf an einer User Story nur arbeiten, wenn er alle erforderlichen Kompetenzen hat
        for (int t = 0; t < vars.T; t++) {
            for (int i = 0; i < vars.N; i++) {
                for (int m = 0; m < vars.M; m++) {
                    final int employeeIndex = m;
                    if (!userStories.get(i).getRequiredCompetencies().stream().allMatch(c -> 
                    employees.get(employeeIndex).hasCompetence(c))) {
                        cplex.addEq(vars.xi[t][i][m], 0);
                    }
                }
            }
        }
        
        // Weitere Nebenbedingungen können hier hinzugefügt werden
    }

    /**
     * Löst das Optimierungsmodell und extrahiert die Ergebnisse.
     * Diese Methode versucht, das erstellte Optimierungsmodell zu lösen und die resultierenden
     * Zuweisungen von User Stories zu Sprints und Mitarbeitern zu extrahieren.
     * 
     * @param cplex Die CPLEX-Instanz, die für die Optimierung verwendet wird.
     * @param vars Die Variablen des Optimierungsmodells.
     * @param userStories Die Liste der User Stories, die den Sprints zugeordnet werden sollen.
     * @param employees Die Liste der Mitarbeiter, die für die Bearbeitung der User Stories verfügbar sind.
     * @param sprintCapacity Die maximale Kapazität eines Sprints.
     * @param sprintTime Die Dauer eines Sprints.
     * @param print Flag, das angibt, ob die Lösung in der Konsole ausgegeben werden soll.
     * @return Eine Liste von Sprints, die jeweils die ihnen zugeordneten User Stories enthalten.
     * @throws IloException Wenn bei der Lösung des Modells ein Fehler auftritt.
     */
    private List<Sprint> solveModel(IloCplex cplex, Variables vars, List<UserStory> userStories, List<Employee> employees, int sprintCapacity, int sprintTime, boolean print) throws IloException {
        List<Sprint> sprints = new ArrayList<>();
        if (cplex.solve()) {
        	// Ausgabe des Zielfunktionswerts
            System.out.println("Lösungsstatus: " + cplex.getStatus());
            System.out.println("Maximaler Gesamtnutzen: " + cplex.getObjValue());
        	// Extraktion und Rückgabe der Ergebnisse
        	for (int t = 0; t < vars.T; t++) {
        		Sprint sprint = new Sprint(sprintCapacity, sprintTime);
        		for (int i = 0; i < vars.N; i++) {
        			for (int m = 0; m < vars.M; m++) {
        				if (cplex.getValue(vars.xi[t][i][m]) > 0.5) {
        					UserStory story = userStories.get(i);
	                        Employee assignedEmployee = employees.get(m);
	                        story.setEmployee(assignedEmployee);
	                        sprint.addUserStory(story);
        				}
        			}
        		}
        		if (!sprint.getUserStories().isEmpty()) {
        			sprints.add(sprint);
        		}
        	}
        	if (print == true) {
	
	            // Ausgabe der Werte für xi zur Überprüfung der gesetzten Werte durch das Modell(wird am Ende entfernt)
	            for (int t = 0; t < vars.T; t++) {
	                for (int i = 0; i < vars.N; i++) {
	                    for (int m = 0; m < vars.M; m++) {
	                        try {
	                            double xiValue = cplex.getValue(vars.xi[t][i][m]);
	                            if (xiValue > 0.5) {
	                                System.out.println("xi[" + t + "][" + i + "][" + m + "] = " + xiValue);
	                            }
	                        } catch (IloCplex.UnknownObjectException e) {
	                            // Variable ist in der Lösung nicht aktiv, daher wird sie ignoriert
	                        }
	                    }
	                }
	            }

	            // Ausgabe der Sprint-Ergebnisse in der Konsole zur Überprüfung mit dem UI(wird am Ende entfernt)
	            int sprintNumber = 1;
	            int totalUtility = 0;
	            int totalComplexity = 0;
	            for (Sprint sprint : sprints) {
	            	System.out.println("Sprint " + sprintNumber + ":");
	            	int sprintUtility = 0;
	            	int sprintComplexity = 0;
	            	for (UserStory story : sprint.getUserStories()) {
	           			System.out.println("UserStory: " + story.getTitle() + ", Bearbeiter: " + (story.getEmployee() != null ? story.getEmployee().getName() : "Kein Mitarbeiter"));
	            		sprintUtility += story.getUtility();
	            		sprintComplexity += story.getComplexity();
	            	}
	            	System.out.println("Sprint Nutzen (Utility): " + sprintUtility);
	           		System.out.println("Sprint Komplexität (StoryPoints): " + sprintComplexity);
	           		System.out.println("--------------------------------------------------");
	           		totalUtility += sprintUtility;
	           		totalComplexity += sprintComplexity;
	           		sprintNumber++;
	           	}
	            System.out.println("Gesamter Nutzen (Utility) über alle Sprints: " + totalUtility);
	           	System.out.println("Gesamte Komplexität (StoryPoints) über alle Sprints: " + totalComplexity);

	           	int totalTimeNeeded = (sprintNumber - 1) * 2;
	           	System.out.println("Gesamte benötigte Zeit (in Wochen): " + totalTimeNeeded);
        	}
           	cplex.close();
        } else {
            System.out.println("Keine Lösung gefunden. Status: " + cplex.getStatus());
        }
        return sprints;
    }
}