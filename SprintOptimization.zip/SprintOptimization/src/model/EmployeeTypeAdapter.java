package model;

import java.io.IOException;
import java.util.List;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

public class EmployeeTypeAdapter extends TypeAdapter<Employee> {
	
	private List<Competence> allCompetencies;
	
	/**
     * Konstruktor für EmployeeTypeAdapter
     * @param allCompetencies Die Liste aller Kompetenzen, um eine Referenzierung zu ermöglichen
     */
    public EmployeeTypeAdapter(List<Competence> allCompetencies) {
        this.allCompetencies = allCompetencies;
    }
    
    /**
     * Liest ein Employee-Objekt aus einem JsonReader.
     * @param in Der JsonReader, aus dem gelesen wird.
     * @return Ein Employee-Objekt, das aus dem JSON gelesen wurde.
     * @throws IOException bei Leseproblemen.
     */
	public Employee read(JsonReader in) throws IOException {
		Employee employee = new Employee();
        
        in.beginObject();
        while (in.hasNext()) {
            String name = in.nextName();
            switch (name) {
                case "id":
                    employee.setId(in.nextInt()); // Liest die ID des Mitarbeiters.
                    break;
                case "name":
                    employee.setName(in.nextString()); // Liest den Namen des Mitarbeiters.
                    break;
                case "surname":
                    employee.setSurname(in.nextString()); // Liest den Nachnamen des Mitarbeiters.
                    break;
                case "employeeCompetencies":
                    in.beginArray();
                    while (in.hasNext()) {
                    	String competenceName = in.nextString();
                        Competence existingCompetence = findCompetenceByName(competenceName);
                        if (existingCompetence == null) {
                        	// Erstellt eine neue Kompetenz, falls nicht vorhanden.
                            existingCompetence = new Competence(competenceName);
                            allCompetencies.add(existingCompetence); // Fügt die neue Kompetenz zum globalen Pool hinzu.
                        }
                        employee.addCompetence(existingCompetence);	// Fügt die Kompetenz dem Mitarbeiter hinzu.
                    }
                    in.endArray();
                    break;
            }
        }
        in.endObject();

        return employee;
	}

	/**
     * Hilfsmethode, um eine Kompetenz anhand ihres Namens in der Liste aller Kompetenzen zu finden.
     * @param name Der Name der zu findenden Kompetenz.
     * @return Das Kompetenz-Objekt, wenn gefunden; sonst null.
     */
	private Competence findCompetenceByName(String name) {
		for (Competence competence : allCompetencies) {
	        if (competence.getName().equals(name)) {
	            return competence;
	        }
	    }
	    return null;
	}

	/**
     * Schreibt ein Employee-Objekt in einen JsonWriter.
     * @param out Der JsonWriter, in den geschrieben wird.
     * @param employee Das Employee-Objekt, das in JSON geschrieben wird.
     * @throws IOException bei Schreibproblemen.
     */
	public void write(JsonWriter out, Employee employee) throws IOException {
		out.beginObject();
        out.name("id").value(employee.getId()); // Schreibt die ID des Mitarbeiters.
        out.name("name").value(employee.getName()); // Schreibt den Namen des Mitarbeiters.
        out.name("surname").value(employee.getSurname()); // Schreibt den Nachnamen des Mitarbeiters.

        out.name("employeeCompetencies");
        out.beginArray();
        for (Competence competence : employee.getCompetencies()) {
            out.value(competence.getName()); // Schreibt die Namen der Kompetenzen des Mitarbeiters.
        }
        out.endArray();

        out.endObject();
	}
}
