package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasse zur Repräsentation einer Kompetenz.
 * Jede Kompetenz hat eine eindeutige ID und einen Namen.
 * Es gibt auch eine statische Liste, die alle erstellten Kompetenzen speichert.
 */
public class Competence {
    
    private static int counter = 0; // Statischer Zähler, um eindeutige IDs zu generieren
    private int id; // Eindeutige ID der Kompetenz
    private String name; // Name der Kompetenz
    private static List<Competence> allCompetencies = new ArrayList<>(); // Statische Liste, die alle Kompetenzen speichert
    
    /**
     * Konstruktor der Kompetenzklasse.
     * Weist jeder neuen Kompetenz eine eindeutige ID zu und setzt den Namen.
     * 
     * @param name Der Name der Kompetenz.
     */
    public Competence(String name) {
        this.id = ++counter; // Erhöht den Zähler und weist die ID zu
        this.name = name; // Setzt den Namen der Kompetenz
    }

    /**
     * Getter für die ID der Kompetenz.
     * 
     * @return Die eindeutige ID der Kompetenz.
     */
    public int getId() {
        return id;
    }   
    
    /**
     * Getter für den Namen der Kompetenz.
     * 
     * @return Der Name der Kompetenz.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter für den Namen der Kompetenz.
     * 
     * @param name Der neue Name der Kompetenz.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Statische Methode, um eine Liste aller erstellten Kompetenzen zu erhalten.
     * 
     * @return Eine neue Liste mit allen erstellten Kompetenzen.
     */
    public static List<Competence> getAllCompetencies() {
        return new ArrayList<>(allCompetencies);
    }

    /**
     * Statische Methode, um eine neue Kompetenz zur globalen Liste hinzuzufügen.
     * 
     * @param competence Die hinzuzufügende Kompetenz.
     */
    public static void addGlobalCompetence(Competence competence) {
        allCompetencies.add(competence);
    }

    /**
     * Überschreibt die standardmäßige toString-Methode.
     * Gibt den Namen der Kompetenz zurück, wenn die Kompetenz als String dargestellt wird.
     * 
     * @return Der Name der Kompetenz.
     */
    public String toString() {
        return name;
    }
}
