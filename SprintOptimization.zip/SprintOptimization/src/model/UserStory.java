package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasse zur Repräsentation einer User Story im agilen Projektmanagement.
 * Eine User Story ist eine detaillierte Anforderung oder Feature-Beschreibung im Softwareentwicklungsprozess.
 */
public class UserStory {
    
    private static int counter = 0; // Statischer Zähler für die eindeutige ID-Zuweisung
    private int id; // Eindeutige ID der User Story
    private String title; // Titel der User Story
    private String description; // Beschreibung der User Story
    private int utility; // Nutzwert der User Story
    private int complexity; // Komplexität der User Story (in Story Points)
    private double critical_risk; // Kritisches Risiko der User Story
    private double uncertainty_risk; // Unsicherheitsrisiko der User Story
    private List<Competence> requiredCompetencies = new ArrayList<>(); // Liste der erforderlichen Kompetenzen
    private Employee employee; // Mitarbeiter, der der User Story zugewiesen ist
    
    
    /**
     * Konstruktor zur Initialisierung einer User Story.
     * @param title Titel der User Story.
     * @param description Detaillierte Beschreibung der User Story.
     * @param utility Nutzwert der User Story für die Priorisierung.
     * @param complexity Komplexität der User Story in Story Points.
     * @param critical_risk Bewertung des kritischen Risikos.
     * @param uncertainty_risk Bewertung des Unsicherheitsrisikos.
     */
    public UserStory(String title, String description, int utility, int complexity,
                     double critical_risk, double uncertainty_risk) {
        this.id = ++counter; // Inkrementiert den Zähler und weist die ID zu
        this.title = title; // Setzt den Titel
        this.description = description; // Setzt die Beschreibung
        this.utility = utility; // Setzt den Nutzwert
        this.complexity = complexity; // Setzt die Komplexität
        this.critical_risk = critical_risk; // Setzt das kritische Risiko
        this.uncertainty_risk = uncertainty_risk; // Setzt das Unsicherheitsrisiko
    }
    
    /**
     * Kopierkonstruktor für die Erstellung einer Kopie einer User Story, z.B. für Simulationen.
     * @param other Die zu kopierende User Story.
     */
    public UserStory(UserStory other) {
        this.id = other.id; // Übernimmt die ID des Originals
        this.title = other.title;
        this.description = other.description;
        this.utility = other.utility;
        this.complexity = other.complexity;
        this.critical_risk = other.critical_risk;
        this.uncertainty_risk = other.uncertainty_risk;
    }
    
    /**
     * Standardkonstruktor für eine User Story ohne spezifizierte Details.
     */
    public UserStory() {
        
    }

    /**
     * Getter-Methode für die ID der User Story.
     * @return Die eindeutige Identifikationsnummer der User Story.
     */
    public int getId() {
        return id;
    }
    
    /**
     * Setter-Methode für die ID der User Story.
     * @param id Die zu setzende Identifikationsnummer der User Story.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Getter-Methode für den Titel der User Story.
     * @return Der Titel der User Story.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Setter-Methode für den Titel der User Story.
     * @param title Der zu setzende Titel der User Story.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Getter-Methode für die Beschreibung der User Story.
     * @return Die Beschreibung der User Story.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter-Methode für die Beschreibung der User Story.
     * @param description Die zu setzende Beschreibung der User Story.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Getter-Methode für den Nutzwert der User Story.
     * @return Der Nutzwert der User Story.
     */
    public int getUtility() {
        return utility;
    }

    /**
     * Setter-Methode für den Nutzwert der User Story.
     * @param utility Der zu setzende Nutzwert der User Story.
     */
    public void setUtility(int utility) {
        this.utility = utility;
    }

    /**
     * Getter-Methode für die Komplexität der User Story.
     * @return Die Komplexität der User Story in Story Points.
     */
    public int getComplexity() {
        return complexity;
    }

    /**
     * Setter-Methode für die Komplexität der User Story.
     * @param complexity Die zu setzende Komplexität der User Story in Story Points.
     */
    public void setComplexity(int complexity) {
        this.complexity = complexity;
    }

    /**
     * Getter-Methode für das kritische Risiko der User Story.
     * @return Das kritische Risiko der User Story.
     */
    public double getCritical_risk() {
        return critical_risk;
    }

    /**
     * Setter-Methode für das kritische Risiko der User Story.
     * @param critical_risk Das zu setzende kritische Risiko der User Story.
     */
    public void setCritical_risk(double critical_risk) {
        this.critical_risk = critical_risk;
    }

    /**
     * Getter-Methode für das Unsicherheitsrisiko der User Story.
     * @return Das Unsicherheitsrisiko der User Story.
     */
    public double getUncertainty_risk() {
        return uncertainty_risk;
    }

    /**
     * Setter-Methode für das Unsicherheitsrisiko der User Story.
     * @param uncertainty_risk Das zu setzende Unsicherheitsrisiko der User Story.
     */
    public void setUncertainty_risk(double uncertainty_risk) {
        this.uncertainty_risk = uncertainty_risk;
    }

    /**
     * Getter-Methode für die Liste der erforderlichen Kompetenzen für die User Story.
     * @return Eine Liste der erforderlichen Kompetenzen für die User Story.
     */
    public List<Competence> getRequiredCompetencies() {
        return new ArrayList<>(requiredCompetencies);
    }
    
    /**
     * Setter-Methode für die Liste der erforderlichen Kompetenzen für die User Story.
     * @param competencies Die zu setzende Liste der erforderlichen Kompetenzen.
     */
    public void setCompetencies(List<Competence> competencies) {
        this.requiredCompetencies = new ArrayList<>(competencies);
    }

    /**
     * Getter-Methode für den zugewiesenen Mitarbeiter für die User Story.
     * @return Der Mitarbeiter, der der User Story zugewiesen ist.
     */
    public Employee getEmployee() {
        return employee;
    }

    /**
     * Setter-Methode für den zugewiesenen Mitarbeiter für die User Story.
     * @param employee Der zuweisende Mitarbeiter für die User Story.
     */
    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
    
    /**
     * Methode zum Hinzufügen einer erforderlichen Kompetenz zur User Story.
     * @param competence Die hinzuzufügende Kompetenz.
     */
    public void addRequiredCompetence(Competence competence) {
        if (!requiredCompetencies.contains(competence)) {
            requiredCompetencies.add(competence);
        }
    }
    
    /**
     * Methode zum Entfernen einer erforderlichen Kompetenz aus der User Story.
     * @param competence Die zu entfernende Kompetenz.
     */
    public void removeRequiredCompetence(Competence competence) {
        requiredCompetencies.remove(competence);
    }
    
    /**
     * Methode zur Anpassung der Komplexität der User Story.
     * @param change Der Wert, um den die Komplexität verändert werden soll.
     */
    public void adjustComplexity(int change) {
        this.complexity += change; // Passt die Komplexität an
        if (this.complexity < 1) {
            this.complexity = 1; // Stellt sicher, dass die Komplexität nicht unter 1 fällt
        }
        if (this.complexity > 10) {
            this.complexity = 10; // Stellt sicher, dass die Komplexität nicht über 10 steigt
        }
    }
    
    /**
     * Methode zur Rückgabe der Anzahl der erforderlichen Kompetenzen für die User Story.
     * @return Die Anzahl der erforderlichen Kompetenzen für die User Story.
     */
    public int getRequiredCompetenciesCount() {
        return this.requiredCompetencies.size();
    }
    
    /**
     * Überschreibt die toString-Methode, um eine Beschreibung der User Story zurückzugeben.
     * @return Eine Beschreibung der User Story.
     */
    public String toString() {
        return "Id: " + this.id + ": " + this.title;
    }
}