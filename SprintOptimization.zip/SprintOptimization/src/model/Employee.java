package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasse zur Repräsentation eines Mitarbeiters.
 * Jeder Mitarbeiter hat eine eindeutige ID, einen Namen, einen Nachnamen und eine Liste von Kompetenzen.
 */
public class Employee {

    private static int counter = 0; // Statischer Zähler für eindeutige Mitarbeiter-IDs
    private int id; // Eindeutige ID des Mitarbeiters
    private String name; // Vorname des Mitarbeiters
    private String surname; // Nachname des Mitarbeiters
    private List<Competence> employeeCompetencies = new ArrayList<>(); // Liste der Kompetenzen des Mitarbeiters
    
    /**
     * Konstruktor für einen Mitarbeiter mit Namen und Nachnamen.
     * @param name Der Vorname des Mitarbeiters.
     * @param surname Der Nachname des Mitarbeiters.
     */
    public Employee(String name, String surname) {
        this.id = ++counter; // Erhöht den Zähler und weist die ID zu
        this.name = name; // Setzt den Vornamen
        this.surname = surname; // Setzt den Nachnamen
    }
    
    /**
     * Standardkonstruktor für einen Mitarbeiter ohne spezifizierte Details.
     */
    public Employee() {
        // Wird verwendet, wenn Mitarbeiter-Details später gesetzt werden.
    }
    
    // Getter und Setter Methoden

    /**
     * Getter für die ID.
     * @return Die ID des Mitarbeiters.
     */
    public int getId() {
        return id;
    }
    
    /**
     * Setter für die ID.
     * @param id Die zu setzende ID.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Getter für den Vornamen.
     * @return Der Vorname des Mitarbeiters.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter für den Vornamen.
     * @param name Der zu setzende Vorname.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter für den Nachnamen.
     * @return Der Nachname des Mitarbeiters.
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Setter für den Nachnamen.
     * @param surname Der zu setzende Nachname.
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Getter für die Liste der Kompetenzen des Mitarbeiters.
     * @return Eine Kopie der Liste der Kompetenzen.
     */
    public List<Competence> getCompetencies() {
        return new ArrayList<>(employeeCompetencies);
    }

    /**
     * Setter für die Liste der Kompetenzen.
     * @param competencies Die Liste der zu setzenden Kompetenzen.
     */
    public void setCompetencies(List<Competence> competencies) {
        this.employeeCompetencies = new ArrayList<>(competencies);
    }

    /**
     * Fügt eine Kompetenz zur Liste der Kompetenzen des Mitarbeiters hinzu.
     * @param competence Die hinzuzufügende Kompetenz.
     */
    public void addCompetence(Competence competence) {
        if (!employeeCompetencies.contains(competence)) {
            employeeCompetencies.add(competence);
        }
    }

    /**
     * Entfernt eine Kompetenz aus der Liste des Mitarbeiters.
     * @param competence Die zu entfernende Kompetenz.
     */
    public void removeCompetence(Competence competence) {
        employeeCompetencies.remove(competence);
    }

    /**
     * Überprüft, ob der Mitarbeiter eine bestimmte Kompetenz besitzt.
     * @param competence Die zu überprüfende Kompetenz.
     * @return Wahr, wenn der Mitarbeiter die Kompetenz besitzt, sonst falsch.
     */
    public boolean hasCompetence(Competence competence) {
        return this.employeeCompetencies.contains(competence);
    }

    /**
     * Überschreibt die toString-Methode, um den vollen Namen des Mitarbeiters zurückzugeben.
     * @return Der volle Name des Mitarbeiters.
     */
    public String toString() {
        return name + " " + surname; // Zeigt den vollen Namen an
    }
}