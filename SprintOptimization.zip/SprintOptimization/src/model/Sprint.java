package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasse zur Repräsentation eines Sprints im agilen Projektmanagement.
 * Ein Sprint hat eine bestimmte Kapazität in Story Points, eine Zeitdauer in Wochen und eine Liste von User Stories.
 */
public class Sprint {
    
    private int capacity; // Kapazität des Sprints in Story Points
    private int time; // Dauer des Sprints in Wochen
    private List<UserStory> userStories; // Liste der dem Sprint zugeordneten User Stories
    
    /**
     * Konstruktor für einen Sprint.
     * @param capacity Die Kapazität des Sprints in Story Points.
     * @param time Die Dauer des Sprints in Wochen.
     */
    public Sprint(int capacity, int time) {
        this.capacity = capacity; // Setzt die Kapazität
        this.time = time; // Setzt die Zeitdauer
        this.userStories = new ArrayList<>(); // Initialisiert die Liste der User Stories
    }
    
    // Getter- und Setter-Methoden

    /**
     * Getter für die Kapazität.
     * @return Die Kapazität des Sprints in Story Points.
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Setter für die Kapazität.
     * @param capacity Die zu setzende Kapazität in Story Points.
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    
    /**
     * Getter für die Zeitdauer.
     * @return Die Zeitdauer des Sprints in Wochen.
     */
    public int getTime() {
        return time;
    }

    /**
     * Setter für die Zeitdauer.
     * @param time Die zu setzende Zeitdauer in Wochen.
     */
    public void setTime(int time) {
        this.time = time;
    }

    /**
     * Methode zum Hinzufügen einer User Story zum Sprint.
     * @param userStory Die hinzuzufügende User Story.
     */
    public void addUserStory(UserStory userStory) {
        userStories.add(userStory); // Fügt die User Story zur Liste hinzu
    }
    
    /**
     * Methode zum Entfernen einer User Story aus dem Sprint.
     * @param userStory Die zu entfernende User Story.
     */
    public void removeUserStory(UserStory userStory) {
        userStories.remove(userStory); // Entfernt die User Story aus der Liste
    }
    
    /**
     * Getter für die Liste der User Stories.
     * @return Eine Kopie der Liste der User Stories im Sprint.
     */
    public List<UserStory> getUserStories() {
        return new ArrayList<>(userStories); // Gibt eine Kopie der Liste zurück
    }
    
    /**
     * Berechnet die gesamte Anzahl an Story Points für die User Stories im Sprint.
     * Jede Story Point Zahl wird durch die Multiplikation der Komplexität mit dem Unsicherheitsrisiko der User Story berechnet.
     * @return Die Summe der Story Points aller User Stories im Sprint.
     */
    public int getCurrentStoryPoints() {
        return userStories.stream()
                          .mapToInt(us -> (int) (us.getComplexity() * us.getUncertainty_risk()))
                          .sum(); // Summiert die angepassten Story Points aller User Stories
    }
}
