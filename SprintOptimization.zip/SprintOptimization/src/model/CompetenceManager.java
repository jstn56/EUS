package model;

/**
 * Hilfsklasse zur Verwaltung und Initialisierung von Kompetenzen.
 * Diese Klasse enthält statische Methoden, um standardmäßige Kompetenzen im System zu initialisieren.
 */
public class CompetenceManager {
    
    /**
     * Statische Methode zum Initialisieren der globalen Kompetenzen.
     * Diese Methode wird aufgerufen, um eine Reihe von Standardkompetenzen im System zu erstellen.
     */
    public static void initializeCompetencies() {
        // Hinzufügen verschiedener Standardkompetenzen zur globalen Liste
        Competence.addGlobalCompetence(new Competence("Frontend")); // Fügt die Kompetenz "Frontend" hinzu
        Competence.addGlobalCompetence(new Competence("Backend"));  // Fügt die Kompetenz "Backend" hinzu
        Competence.addGlobalCompetence(new Competence("Database")); // Fügt die Kompetenz "Database" hinzu
        Competence.addGlobalCompetence(new Competence("Administration"));  // Fügt die Kompetenz "Administration" hinzu
    }
}