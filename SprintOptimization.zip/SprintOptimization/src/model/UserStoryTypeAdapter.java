package model;

import java.io.IOException;
import java.util.List;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

public class UserStoryTypeAdapter extends TypeAdapter<UserStory> {
	private List<Competence> allCompetencies;

	/**
     * Konstruktor für UserStoryTypeAdapter.
     * @param allCompetencies Liste aller Kompetenzen, die zur Zuweisung an User Stories verwendet werden.
     */
    public UserStoryTypeAdapter(List<Competence> allCompetencies) {
        this.allCompetencies = allCompetencies;
    }
    
    /**
     * Liest ein UserStory-Objekt aus einem JsonReader.
     * @param in Der JsonReader, aus dem gelesen wird.
     * @return Ein UserStory-Objekt, das aus dem JSON gelesen wurde.
     * @throws IOException bei Leseproblemen.
     */
	public UserStory read(JsonReader in) throws IOException {
		UserStory story = new UserStory();
        
        in.beginObject();
        while (in.hasNext()) {
            String name = in.nextName();
            switch (name) {
                case "id":
                    story.setId(in.nextInt()); // Liest die ID der User Story.
                    break;
                case "title":
                    story.setTitle(in.nextString()); // Liest den Titel der User Story.
                    break;
                case "description":
                    story.setDescription(in.nextString()); // Liest die Beschreibung der User Story.
                    break;
                case "utility":
                    story.setUtility(in.nextInt()); // Liest den Nutzwert der User Story.
                    break;
                case "complexity":
                    story.setComplexity(in.nextInt()); // Liest die Komplexität der User Story.
                    break;
                case "critical_risk":
                    story.setCritical_risk(in.nextDouble()); // Liest das kritische Risiko der User Story.
                    break;
                case "uncertainty_risk":
                    story.setUncertainty_risk(in.nextDouble()); // Liest das Unsicherheitsrisiko der User Story.
                    break;
                case "requiredCompetencies":
                    in.beginArray();
                    while (in.hasNext()) {
                    	String competenceName = in.nextString();
                        Competence existingCompetence = findCompetenceByName(competenceName);
                        if (existingCompetence == null) {
                            existingCompetence = new Competence(competenceName);
                            allCompetencies.add(existingCompetence); // Aktualisiert den globalen Pool der Kompetenzen.
                        }
                        story.addRequiredCompetence(existingCompetence); // Fügt die Kompetenz zur User Story hinzu.
                    }
                    in.endArray();
                    break;
            }
        }
        in.endObject();

        return story;
	}

	/**
     * Hilfsmethode, um eine Kompetenz anhand ihres Namens zu finden.
     * @param name Der Name der gesuchten Kompetenz.
     * @return Das gefundene Kompetenz-Objekt oder null, falls nicht gefunden.
     */
	private Competence findCompetenceByName(String name) {
		for (Competence competence : allCompetencies) {
	        if (competence.getName().equals(name)) {
	            return competence;
	        }
	    }
	    return null;
	}

	/**
     * Schreibt ein UserStory-Objekt in einen JsonWriter.
     * @param out Der JsonWriter, in den geschrieben wird.
     * @param story Das UserStory-Objekt, das in JSON geschrieben wird.
     * @throws IOException bei Schreibproblemen.
     */
	public void write(JsonWriter out, UserStory story) throws IOException {
		out.beginObject();
        out.name("id").value(story.getId()); // Schreibt die ID der User Story.
        out.name("title").value(story.getTitle()); // Schreibt den Titel der User Story.
        out.name("description").value(story.getDescription()); // Schreibt die Beschreibung der User Story.
        out.name("utility").value(story.getUtility()); // Schreibt den Nutzwert der User Story.
        out.name("complexity").value(story.getComplexity()); // Schreibt die Komplexität der User Story.
        out.name("critical_risk").value(story.getCritical_risk()); // Schreibt das kritische Risiko der User Story.
        out.name("uncertainty_risk").value(story.getUncertainty_risk()); // Schreibt das Unsicherheitsrisiko der User Story.
        
        out.name("requiredCompetencies");
        out.beginArray();
        for (Competence competence : story.getRequiredCompetencies()) {
            out.value(competence.getName()); // Schreibt die Namen der erforderlichen Kompetenzen der User Story.
        }
        out.endArray();

        out.endObject();
	}
}
