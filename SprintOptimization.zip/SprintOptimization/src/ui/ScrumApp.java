package ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import algorithm.MonteCarloSimulation;
import algorithm.UserStoryAssignment;
import ilog.concert.IloException;
import model.Competence;
import model.Employee;
import model.EmployeeTypeAdapter;
import model.Sprint;
import model.UserStory;
import model.UserStoryTypeAdapter;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;

public class ScrumApp {
	
	private JFrame frame;
	private DefaultListModel<UserStory> backlogModel;
	private DefaultListModel<Employee> mitarbeiterModel;
	private DefaultListModel<Competence> competenceModel;
	private UserStoryAssignment userStoryAssignment = new UserStoryAssignment();
	private JList<UserStory> userStoryList;
	private JList<Employee> employeeList;
	private JList<Competence> competenceList;
	private List<UserStory> userStories;
	private List<Employee> employees;
	private List<Sprint> sprints;
	private List<Competence> allCompetencies;
	private JTable sprintTable;
	private Map<Integer, Integer> histogram;
	private int sprintCapacity = 21;
	private int sprintTime = 2;
	private int currentSprintIndex = 0;
	private int simulations = 100;
	private int minChange = -1;
	private int maxChange = 2;
	private int maxNewUserStories = 2;
	private int minNew = 1;
	private int maxNew = 2;
	private JLabel totalUtilityLabel;
	private JLabel totalComplexityLabel;
	private JLabel totalTimeLabel;
	private JLabel sprintNumberLabel;
	private JButton btnBurnDownChart;

	/**
	 * Konstruktor für die ScrumApp-Klasse.
	 * @param userStories Liste der User Stories.
	 * @param employees Liste der Mitarbeiter.
	 * @param allCompetencies Liste aller Kompetenzen.
	 */
	public ScrumApp(List<UserStory> userStories, List<Employee> employees, List<Competence> allCompetencies) {
	    // Initialisierung der List-Modelle mit den übergebenen Listen
	    backlogModel = new DefaultListModel<>();
	    userStories.forEach(backlogModel::addElement); // Fügt jede User Story dem Backlog-Model hinzu

	    mitarbeiterModel = new DefaultListModel<>();
	    employees.forEach(mitarbeiterModel::addElement); // Fügt jeden Mitarbeiter dem Mitarbeiter-Model hinzu
	    
	    competenceModel = new DefaultListModel<>();
	    allCompetencies.forEach(competenceModel::addElement); // Fügt jede Kompetenz dem Kompetenz-Model hinzu
    
	    this.userStories = userStories;
	    this.employees = employees;
	    this.allCompetencies = allCompetencies;
	    this.sprintTable = new JTable(new DefaultTableModel(new Object[]{"User Stories", "Mitarbeiter"}, 0));
	    // Initialisierung der JLists mit den Modellen
	    userStoryList = new JList<>(backlogModel); // JList für User Stories
	    employeeList = new JList<>(mitarbeiterModel); // JList für Mitarbeiter
	    competenceList = new JList<>(competenceModel); // JList für Kompetenzen

	    createAndShowGUI(); // Erstellt und zeigt die Benutzeroberfläche
	}
	
	/**
	 * Erstellt und zeigt die grafische Benutzeroberfläche (GUI) der Anwendung.
	 * Diese Methode initialisiert und ordnet verschiedene UI-Komponenten an, 
	 * darunter Panels, Buttons, Labels, ScrollPanes und Menüelemente, 
	 * die für die Darstellung und Interaktion innerhalb der Anwendung erforderlich sind.
	 */
	private void createAndShowGUI() {
		// Hauptfenster für die Anwendung erstellen
		frame = new JFrame("Entscheidungsunterstützungssystem zur Optimierung agiler Softwareprojekte");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Legt fest, dass die Anwendung beim Schließen des Fensters beendet wird
        frame.setLayout(new BorderLayout()); // Setzt das Layout für das Hauptfenster
            
        // Linkes Panel für die Anzeige von Listen
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS)); // Vertikales BoxLayout für das linke Panel

        
        // Panel für die User Story Liste
        JPanel userStoryPanel = new JPanel();
        userStoryPanel.setLayout(new BorderLayout());
        JLabel userStoryLabel = new JLabel("Product Backlog");
        userStoryPanel.add(userStoryLabel, BorderLayout.NORTH);
        JScrollPane scrollPaneBacklog = createScrollPane(userStoryList, createUserStoryPopupMenu());
        userStoryPanel.add(scrollPaneBacklog, BorderLayout.CENTER);
        leftPanel.add(userStoryPanel); // Fügt das User Story Panel zum linken Panel hinzu

        // Panel für die Mitarbeiter Liste
        JPanel mitarbeiterPanel = new JPanel();
        mitarbeiterPanel.setLayout(new BorderLayout());
        JLabel mitarbeiterLabel = new JLabel("Mitarbeiter");
        mitarbeiterPanel.add(mitarbeiterLabel, BorderLayout.NORTH);
        JScrollPane scrollPaneMitarbeiter = createScrollPane(employeeList, createEmployeePopupMenu());
        mitarbeiterPanel.add(scrollPaneMitarbeiter, BorderLayout.CENTER);
        leftPanel.add(mitarbeiterPanel); // Fügt das Mitarbeiter Panel zum linken Panel hinzu

        // Panel für den Multi-Sprint-Planung-Button
        JPanel multiSprintPlanungPanel = new JPanel();
        multiSprintPlanungPanel.setLayout(new BoxLayout(multiSprintPlanungPanel, BoxLayout.X_AXIS));
        JButton btnMultiSprintPlanung = new JButton("Multi-Sprint-Planung starten");
        btnMultiSprintPlanung.setMaximumSize(new Dimension(100, 30));
        btnMultiSprintPlanung.addActionListener(e -> performMultiSprintPlanning()); // Aktion bei Klick auf den Button

        // Hinzufügen von Glue (flexiblen Abstandshaltern) und dem Button zum Panel
        multiSprintPlanungPanel.add(Box.createHorizontalGlue());
        multiSprintPlanungPanel.add(btnMultiSprintPlanung);
        multiSprintPlanungPanel.add(Box.createHorizontalGlue());

        // Hinzufügen des Buttons zum linken Panel
        leftPanel.add(multiSprintPlanungPanel);

        // Mittleres Panel für die Sprint-Tabelle und Ergebnis-Labels
        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        
        // ScrollPane für die Sprint-Tabelle
        JScrollPane tableScrollPane = new JScrollPane(sprintTable);
        centerPanel.add(tableScrollPane);

        // Unteres Panel für Gesamtergebnisse und Pfeil-Buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Panel für die Anzeige der Gesamtergebnisse (Labels)
        JPanel resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));

        // Initialisierung und Hinzufügen der Ergebnis-Labels zum Panel
        sprintNumberLabel = new JLabel("Anzahl der Sprints: 0");
        totalUtilityLabel = new JLabel("Gesamter Nutzen (Utility) über alle Sprints: 0");
        totalComplexityLabel = new JLabel("Gesamte Komplexität (StoryPoints) über alle Sprints: 0");
        totalTimeLabel = new JLabel("Gesamt benötigte Zeit (in Wochen): 0");

        resultsPanel.add(sprintNumberLabel);
        resultsPanel.add(totalUtilityLabel);
        resultsPanel.add(totalComplexityLabel);
        resultsPanel.add(totalTimeLabel);
        
        // Erstellen des Buttons für das Burn-Down-Chart
        btnBurnDownChart = new JButton("Burn-Down-Chart");
        btnBurnDownChart.setVisible(false); // Zunächst unsichtbar
        // ActionListener für den Button, der die Methode aufruft, um das Burn-Down-Chart anzuzeigen
        btnBurnDownChart.addActionListener(e -> showBurnDownChart());

        // Hinzufügen des Burn-Down-Chart-Buttons zum resultsPanel
        resultsPanel.add(btnBurnDownChart);
        // Hinzufügen des resultsPanel zum bottomPanel
        bottomPanel.add(resultsPanel);

        // Erstellen des Panels für Pfeil-Buttons zur Navigation zwischen den Sprints
        JPanel arrowButtonsPanel = new JPanel();
        JButton leftArrowButton = new JButton("<");
        JButton rightArrowButton = new JButton(">");
        arrowButtonsPanel.add(leftArrowButton);
        arrowButtonsPanel.add(rightArrowButton);
        bottomPanel.add(arrowButtonsPanel);

        // Hinzufügen des bottomPanel zum centerPanel
        centerPanel.add(bottomPanel);
        // ActionListener für den linken Pfeil-Button, um zum vorherigen Sprint zu navigieren
        leftArrowButton.addActionListener(e -> {
            if (currentSprintIndex > 0) {
                currentSprintIndex--;
                updateTableWithSprintData(sprints.get(currentSprintIndex));
            }
        });
        // ActionListener für den rechten Pfeil-Button, um zum nächsten Sprint zu navigieren
        rightArrowButton.addActionListener(e -> {
            if (currentSprintIndex < sprints.size() - 1) {
                currentSprintIndex++;
                updateTableWithSprintData(sprints.get(currentSprintIndex));
            }
        });
        
        //Überschrift für den Bereich der Multi-Sprint-Planung
        JPanel centerPanelContainer = new JPanel(new BorderLayout());
        JLabel centerPanelHeader = new JLabel("Multi-Sprint-Planung", SwingConstants.CENTER);
        centerPanelContainer.add(centerPanelHeader, BorderLayout.NORTH);
        centerPanelContainer.add(centerPanel, BorderLayout.CENTER);
        
        // Rechte Panel für die Monte-Carlo-Simulation Einstellungen
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        
        // Labels und Checkboxen für die Auswahl der Szenarien
        JLabel lblChooseScenarios = new JLabel("Bitte wählen Sie die gewünschten Szenarien aus:");
        JCheckBox cbWechselndeAnforderungen = new JCheckBox("Wechselnde Anforderungen");
        JCheckBox cbNeueAnforderungen = new JCheckBox("Neue Anforderungen");
        JCheckBox cbKuendigungen = new JCheckBox("Kündigungen");
        // Button zum Starten der Monte-Carlo-Simulation
        JButton btnMonteCarloSimulation = new JButton("Monte-Carlo-Simulation starten");
        
        // Hinweistext und Ladebalken für die Simulation
        JLabel lblSimulationHinweis = new JLabel("Die Simulation kann einige Sekunden dauern:");
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setVisible(false);
        lblSimulationHinweis.setVisible(false);

        // Label für die Anzeige der Simulationsdauer
        JLabel lblSimulationsdauer = new JLabel("");
        lblSimulationsdauer.setVisible(false);
        
        // Textbereich für die Ergebnisse der Simulation
        JTextArea simulationResultsArea = new JTextArea(10, 30);
        simulationResultsArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(simulationResultsArea);
        
        // Button zum Anzeigen des Histogramms der Simulationsergebnisse
        JButton btnShowHistogram = new JButton("Histogramm anzeigen");
        btnShowHistogram.setVisible(false); // Zunächst unsichtbar
        
        // ActionListener für die Monte-Carlo-Simulation
        btnMonteCarloSimulation.addActionListener(e -> performMonteCarloSimulation(progressBar, simulationResultsArea, lblSimulationHinweis, lblSimulationsdauer, 
        		btnShowHistogram, cbWechselndeAnforderungen, cbNeueAnforderungen, cbKuendigungen));
        
        // ActionListener für die Anzeige des Histogramms
        btnShowHistogram.addActionListener(e -> showHistogram(histogram));
             
        // Layout-Einstellungen für das rechte Panel
        rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        rightPanel.add(lblChooseScenarios);
        rightPanel.add(cbWechselndeAnforderungen);
        rightPanel.add(cbNeueAnforderungen);
        rightPanel.add(cbKuendigungen);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        rightPanel.add(btnMonteCarloSimulation);
        rightPanel.add(lblSimulationHinweis);
        rightPanel.add(progressBar);
        rightPanel.add(lblSimulationsdauer);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 5)));
        rightPanel.add(btnShowHistogram);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        rightPanel.add(scrollPane);
        
        // Hinzufügen der Überschrift der Monte-Carlo-Simulation
        JPanel rightPanelContainer = new JPanel(new BorderLayout());
        JLabel rightPanelHeader = new JLabel("Monte-Carlo-Simulation", SwingConstants.CENTER);
        rightPanelContainer.add(rightPanelHeader, BorderLayout.NORTH);
        rightPanelContainer.add(rightPanel, BorderLayout.CENTER);
        
        // Hinzufügen der Panels zum Hauptfenster
        frame.add(leftPanel, BorderLayout.WEST);
        frame.add(centerPanelContainer, BorderLayout.CENTER);
        frame.add(rightPanelContainer, BorderLayout.EAST);

        // Menüleiste erstellen
	    JMenuBar menuBar = new JMenuBar();

	    // Menü für Einstellungen
	    JMenu settingsMenu = new JMenu("Einstellungen");
	    JMenuItem settingsItem = new JMenuItem("Berechnungsvariablen bearbeiten");
	    JMenuItem competenceItem = new JMenuItem("Kompetenzen bearbeiten");
	    JMenuItem productBacklogItem = new JMenuItem("Product Backlog laden");
	    JMenuItem employeeItem = new JMenuItem("Mitarbeiter laden");

	    settingsMenu.add(settingsItem);
	    settingsMenu.add(competenceItem);
	    settingsMenu.add(productBacklogItem);
	    settingsMenu.add(employeeItem);
	    
	    // ActionListeners für Menüelemente
	    settingsItem.addActionListener(e -> openSettingsDialog());
	    competenceItem.addActionListener(e -> openCompetenceDialog());
	    productBacklogItem.addActionListener(e -> openProductBacklogDialog()); 
	    employeeItem.addActionListener(e -> openEmployeeDialog());    

	    menuBar.add(settingsMenu);
	    
	    frame.setJMenuBar(menuBar);
        frame.setSize(1300, 650);
        frame.setVisible(true);
    }
	
	/**
	 * Zeigt ein Histogramm basierend auf den übergebenen Daten.
	 * @param histogram Die Daten, die im Histogramm dargestellt werden sollen.
	 */
	private void showHistogram(Map<Integer, Integer> histogram) {
	    // Erstellen des Datasets für das Balkendiagramm
	    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
	    for (Map.Entry<Integer, Integer> entry : histogram.entrySet()) {
	        // Fügt jedem Datensatz die Anzahl der Vorkommen für jede Woche hinzu
	        dataset.addValue(entry.getValue(), "Auftrittshäufigkeit", entry.getKey() + " Wochen");
	    }

	    // Erstellen des Balkendiagramms mit JFreeChart
	    JFreeChart barChart = ChartFactory.createBarChart(
	            "Darstellung der Simulationsergebnisse", // Titel des Diagramms
	            "Wochen", // X-Achsenbeschriftung
	            "Auftrittshäufigkeit", // Y-Achsenbeschriftung
	            dataset, // Daten für das Diagramm
	            PlotOrientation.VERTICAL, // Orientierung des Diagramms
	            false, // Legende anzeigen
	            true, // Tooltips anzeigen
	            false // URLs verwenden
	    );

	    // Anzeigen des Balkendiagramms in einem neuen Fenster
	    ChartPanel chartPanel = new ChartPanel(barChart);
	    JFrame frame = new JFrame("Histogramm");
	    frame.setContentPane(chartPanel); // Setzt das Diagramm als Inhalt des Fensters
	    frame.setSize(800, 600); // Größe des Fensters
	    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Verhalten beim Schließen
	    frame.setVisible(true); // Fenster sichtbar machen
	}
	
	/**
	 * Führt die Monte-Carlo-Simulation aus und aktualisiert die Benutzeroberfläche mit den Ergebnissen.
	 * @param progressBar Die Fortschrittsleiste, die den Fortschritt der Simulation anzeigt.
	 * @param simulationResultsArea Das Textfeld, in dem die Ergebnisse der Simulation angezeigt werden.
	 * @param lblSimulationHinweis Ein Label, das Hinweise zur laufenden Simulation anzeigt.
	 * @param lblSimulationsdauer Ein Label, das die Dauer der Simulation anzeigt.
	 * @param btnShowHistogram Ein Button, um das Histogramm der Simulationsergebnisse anzuzeigen.
	 * @param cbWechselndeAnforderungen Checkbox für die Option "Wechselnde Anforderungen".
	 * @param cbNeueAnforderungen Checkbox für die Option "Neue Anforderungen".
	 * @param cbKuendigungen Checkbox für die Option "Kündigungen".
	 */
	private void performMonteCarloSimulation(JProgressBar progressBar, JTextArea simulationResultsArea,
	        JLabel lblSimulationHinweis, JLabel lblSimulationsdauer, JButton btnShowHistogram,
	        JCheckBox cbWechselndeAnforderungen, JCheckBox cbNeueAnforderungen, JCheckBox cbKuendigungen) {
	    
	    progressBar.setMaximum(simulations); // Setzt den Maximalwert der ProgressBar
	    progressBar.setValue(0);
	    progressBar.setIndeterminate(false); // Verwendet den determinaten Modus
	    progressBar.setVisible(true);
	    lblSimulationHinweis.setVisible(true);

	    new Thread(() -> {
	        long startTime = System.currentTimeMillis();

	        try {
	            // Einstellungen der Simulation basierend auf den ausgewählten Optionen
	            boolean wechselndeAnforderungen = cbWechselndeAnforderungen.isSelected();
	            boolean neueAnforderungen = cbNeueAnforderungen.isSelected();
	            boolean kuendigungen = cbKuendigungen.isSelected();
	        	
	            // Durchführen der Monte Carlo Simulation
	            MonteCarloSimulation simulation = new MonteCarloSimulation(userStoryAssignment, userStories, employees, sprintCapacity, sprintTime, allCompetencies);
	            histogram = simulation.simulate(simulations, minChange, maxChange, maxNewUserStories, minNew, maxNew, wechselndeAnforderungen, neueAnforderungen, kuendigungen, progress -> {
	                SwingUtilities.invokeLater(() -> progressBar.setValue(progress));
	            });
	        	
	            // Aufbereiten und Anzeigen der Simulationsergebnisse
	            List<Map.Entry<Integer, Integer>> sortedEntries = new ArrayList<>(histogram.entrySet());
	            sortedEntries.sort(Map.Entry.comparingByKey());
	            StringBuilder resultsString = new StringBuilder();
	            for (Map.Entry<Integer, Integer> entry : histogram.entrySet()) {
	                resultsString.append("Wochen: ").append(entry.getKey()).append(", Auftrittshäufigkeit: ").append(entry.getValue()).append("\n");
	            }
	            simulationResultsArea.setText(resultsString.toString());
	            btnShowHistogram.setVisible(true);
	            
	            // Aktualisieren der Benutzeroberfläche nach Abschluss der Simulation
	            SwingUtilities.invokeLater(() -> {
	                progressBar.setVisible(false);
	                lblSimulationHinweis.setVisible(false);
	                lblSimulationsdauer.setText("Simulationsdauer: " + (System.currentTimeMillis() - startTime) / 1000.0 + " Sekunden");
	                lblSimulationsdauer.setVisible(true);
	            });                 
	        } catch (IloException ex) {
	            ex.printStackTrace();
	            JOptionPane.showMessageDialog(frame, "Fehler bei der Monte-Carlo-Simulation: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
	        }
	    }).start();
	}

	/**
	 * Erstellt und zeigt ein Burn-Down-Chart basierend auf den Sprintdaten an.
	 * Das Burn-Down-Chart visualisiert den Fortschritt der Story Points über die Zeit.
	 */
	private void showBurnDownChart() {
	    // Erstellen der Daten für das Burn-Down-Chart
	    DefaultCategoryDataset burnDownData = createBurnDownData(sprints, sprintTime);

	    // Erstellen des Charts mit JFreeChart
	    JFreeChart chart = ChartFactory.createLineChart(
	        "Darstellung des Projektverlaufs", // Titel des Charts
	        "Zeit", // Beschriftung der X-Achse
	        "Story Points", // Beschriftung der Y-Achse
	        burnDownData, // Daten für das Chart
	        PlotOrientation.VERTICAL, // Vertikale Orientierung des Charts
	        true, // Keine Legende
	        true, // Tooltips aktivieren
	        false // Keine URLs
	    );

	    // Anpassen des Plots und der Renderer-Eigenschaften
	    CategoryPlot plot = (CategoryPlot) chart.getPlot();
	    LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot.getRenderer();
	    
	    // Setzen der Farben und eventuell der Stricharten für die Serien
	    renderer.setSeriesPaint(0, Color.BLUE); // Farbe der aktuellen Linie der Story Points
	    renderer.setSeriesStroke(0, new BasicStroke(2.0f)); // Dicke der aktuellen Linie

	    renderer.setSeriesPaint(1, Color.RED); // Farbe der Ideal-Linie
	    renderer.setSeriesStroke(1, new BasicStroke(2.0f, BasicStroke.CAP_BUTT, 
	                                                BasicStroke.JOIN_BEVEL, 1.0f, 
	                                                new float[]{10f, 6f}, 0f)); // Gestrichelte Linie für die Ideal-Linie

	    // Erstellen eines ChartPanels und eines JFrame zur Anzeige des Charts
	    ChartPanel chartPanel = new ChartPanel(chart);
	    JFrame chartFrame = new JFrame("Burn-Down-Chart");
	    chartFrame.setContentPane(chartPanel); // ChartPanel als Inhalt des Fensters setzen
	    chartFrame.setSize(800, 400); // Größe des Fensters festlegen
	    chartFrame.setVisible(true); // Fenster sichtbar machen
	}

	/**
	 * Führt die Multi-Sprint-Planung aus und aktualisiert die Benutzeroberfläche mit den Planungsergebnissen.
	 */
	private void performMultiSprintPlanning() {
	    try {
	        // Zuweisung von User Stories zu Sprints unter Verwendung der UserStoryAssignment-Klasse
	        sprints = userStoryAssignment.assignUserStoriesToSprintsCPLEX(userStories, employees, sprintCapacity, sprintTime, true);
	        
	        // Initialisierung von Variablen für die Berechnung der Gesamtergebnisse
	        int sprintNumber = 1;
	        int totalUtility = 0;
	        int totalComplexity = 0;

	        // Durchlaufen aller Sprints und Summierung von Nutzen und Komplexität
	        for (Sprint sprint : sprints) {
	            int sprintUtility = 0;
	            int sprintComplexity = 0;
	            for (UserStory story : sprint.getUserStories()) {
	                sprintUtility += story.getUtility() * story.getCritical_risk();
	                sprintComplexity += story.getComplexity() * story.getUncertainty_risk();
	            }
	            totalUtility += sprintUtility;
	            totalComplexity += sprintComplexity;
	            sprintNumber++;
	        };

	        // Berechnung der Gesamtzeit, die für alle Sprints benötigt wird
	        int totalTimeNeeded = (sprintNumber - 1) * sprintTime;

	        // Aktualisieren der Gesamtergebnisse auf der Benutzeroberfläche
	        updateTotalResults(sprintNumber, totalUtility, totalComplexity, totalTimeNeeded);

	        // Sichtbarmachen des Buttons für das Burn-Down-Chart
	        btnBurnDownChart.setVisible(true);

	        // Aktualisieren der Tabelle mit Daten des ersten Sprints, wenn Sprints vorhanden sind
	        if (!sprints.isEmpty()) {
	            updateTableWithSprintData(sprints.get(0));
	        }
	    } catch (IloException ex) {
	        // Fehlerbehandlung, wenn bei der Planung ein Fehler auftritt
	        ex.printStackTrace();
	        JOptionPane.showMessageDialog(frame, "Fehler bei der Multi-Sprint-Planung: " + ex.getMessage(), "Fehler", JOptionPane.ERROR_MESSAGE);
	    }
	}

	/**
	 * Erstellt ein Pop-up-Menü für User Stories mit verschiedenen Aktionen.
	 * @return Das erstellte JPopupMenu für User Stories.
	 */
	private JPopupMenu createUserStoryPopupMenu() {
	    JPopupMenu menu = new JPopupMenu();
	    menu.add(createMenuItem("Anzeigen", e -> showUserStoryDetails(userStoryList.getSelectedValue())));
	    menu.add(createMenuItem("Bearbeiten", e -> editUserStoryDetails(userStoryList.getSelectedValue())));
	    menu.add(createMenuItem("Löschen", e -> removeUserStory(userStoryList.getSelectedValue())));
	    menu.add(createMenuItem("Hinzufügen", e -> addNewUserStory()));
	    return menu;
	}

	/**
	 * Erstellt ein Pop-up-Menü für Mitarbeiter mit verschiedenen Aktionen.
	 * @return Das erstellte JPopupMenu für Mitarbeiter.
	 */
	private JPopupMenu createEmployeePopupMenu() {
	    JPopupMenu menu = new JPopupMenu();
	    menu.add(createMenuItem("Anzeigen", e -> showEmployeeDetails(employeeList.getSelectedValue())));
	    menu.add(createMenuItem("Bearbeiten", e -> editEmployeeDetails(employeeList.getSelectedValue())));
	    menu.add(createMenuItem("Löschen", e -> removeEmployee(employeeList.getSelectedValue())));
	    menu.add(createMenuItem("Hinzufügen", e -> addNewEmployee()));
	    return menu;
	}

	/**
	 * Hilfsmethode zum Erstellen eines JMenuItem mit einem ActionListener.
	 * @param title Der Titel des Menüpunktes.
	 * @param action Der ActionListener, der dem Menüpunkt hinzugefügt wird.
	 * @return Das erstellte JMenuItem.
	 */
	private JMenuItem createMenuItem(String title, ActionListener action) {
	    JMenuItem menuItem = new JMenuItem(title);
	    menuItem.addActionListener(action);
	    return menuItem;
	}

	/**
	 * Erstellt ein JScrollPane mit einem zugehörigen Pop-up-Menü.
	 * @param list Die JList, für die das ScrollPane erstellt wird.
	 * @param menu Das Pop-up-Menü, das der JList hinzugefügt wird.
	 * @return Das erstellte JScrollPane.
	 */
	private JScrollPane createScrollPane(JList<?> list, JPopupMenu menu) {
	    list.addMouseListener(new MouseAdapter() {
	        public void mouseClicked(MouseEvent e) {
	            if (SwingUtilities.isRightMouseButton(e)) {
	                menu.show(list, e.getX(), e.getY());
	            }
	        }
	    });
	    return new JScrollPane(list);
	}

	/**
	 * Interface für einen Listener, der den Fortschritt der Simulation aktualisiert.
	 */
	public interface SimulationProgressListener {
	    void onProgressUpdate(int progress);
	}
	
	/**
	 * Öffnet ein Dialogfenster, um eine neue User Story hinzuzufügen.
	 * Benutzer können Details wie Titel, Beschreibung, Nutzwert, Komplexität und Risiken eingeben.
	 */
	private void addNewUserStory() {
		JDialog addDialog = new JDialog(frame, "Neue UserStory hinzufügen", true);
	    addDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Eingabefelder für die Eigenschaften der User Story
	    JTextField titleField = new JTextField(20);
	    JTextField descriptionField = new JTextField(20);
	    JTextField utilityField = new JTextField(5);
	    JTextField complexityField = new JTextField(5);
	    JTextField criticalRiskField = new JTextField(5);
	    JTextField uncertaintyRiskField = new JTextField(5);

	    // Hinzufügen der Labels und Eingabefelder zum Dialog
	    // Titel
	    addDialog.add(new JLabel("Titel:"), gbc);
	    gbc.gridx++;
	    addDialog.add(titleField, gbc);

	    // Beschreibung
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Beschreibung:"), gbc);
	    gbc.gridx++;
	    addDialog.add(descriptionField, gbc);

	    // Nutzwert
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Nutzwert (Utility):"), gbc);
	    gbc.gridx++;
	    addDialog.add(utilityField, gbc);

	    // Komplexität
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Komplexität (Story Points):"), gbc);
	    gbc.gridx++;
	    addDialog.add(complexityField, gbc);

	    // Kritisches Risiko
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Kritisches Risiko:"), gbc);
	    gbc.gridx++;
	    addDialog.add(criticalRiskField, gbc);

	    // Unsicherheitsrisiko
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Unsicherheitsrisiko:"), gbc);
	    gbc.gridx++;
	    addDialog.add(uncertaintyRiskField, gbc);

	    // Liste der Kompetenzen
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Kompetenzen:"), gbc);
	    gbc.gridx++;

	    // Verwenden Sie das DefaultListModel für die Kompetenzen
	    DefaultListModel<Competence> tempCompetenciesModel = new DefaultListModel<>();
	    JList<Competence> competenciesList = new JList<>(tempCompetenciesModel);
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    addDialog.add(competenciesScrollPane, gbc);

	    // Button zum Hinzufügen von Kompetenzen
	    JButton addCompetenceButton = new JButton("+");
	    addCompetenceButton.addActionListener(e -> openCompetenceSelectionDialog(tempCompetenciesModel));
	    gbc.gridx++;
	    addDialog.add(addCompetenceButton, gbc);
	    
	    // Hinzufügen-Button
	    gbc.gridx = 0;
	    gbc.gridy++;
	    gbc.gridwidth = 2; // Über zwei Spalten
	    JButton addButton = new JButton("Hinzufügen");
	    addButton.addActionListener(e -> {
	    	// Validierung und Verarbeitung der Eingaben
	        try {
	            String newTitle = titleField.getText().trim();
	            String newDescription = descriptionField.getText().trim();
	            int newUtility = Integer.parseInt(utilityField.getText().trim());
	            int newComplexity = Integer.parseInt(complexityField.getText().trim());
	            double newCriticalRisk = Double.parseDouble(criticalRiskField.getText().trim().replace(',', '.'));
	            double newUncertaintyRisk = Double.parseDouble(uncertaintyRiskField.getText().trim().replace(',', '.'));

	            UserStory newUserStory = new UserStory(newTitle, newDescription, newUtility, newComplexity, newCriticalRisk, newUncertaintyRisk);
	            // Hinzufügen der Kompetenzen und User Story zur Liste und zum Model
	            for (int i = 0; i < tempCompetenciesModel.size(); i++) {
	                newUserStory.addRequiredCompetence(tempCompetenciesModel.get(i));
	            }
	            // UserStory zur internen Liste und zum Model der JList hinzufügen
	            userStories.add(newUserStory);
	            ((DefaultListModel<UserStory>)userStoryList.getModel()).addElement(newUserStory);

	            addDialog.dispose();
	        } catch (NumberFormatException ex) {
	            JOptionPane.showMessageDialog(addDialog, "Bitte geben Sie gültige Zahlenwerte ein.", "Eingabefehler", JOptionPane.ERROR_MESSAGE);
	        }
	    });

	    gbc.gridx = 1;
	    gbc.gridy++;
	    addDialog.add(addButton, gbc);

	    addDialog.pack();
	    addDialog.setLocationRelativeTo(frame);
	    addDialog.setVisible(true);
	}

	/**
	 * Öffnet ein Dialogfenster, um einen neuen Mitarbeiter hinzuzufügen.
	 * Benutzer können Details wie Name, Nachname und Kompetenzen eingeben.
	 */
	private void addNewEmployee() {
		JDialog addDialog = new JDialog(frame, "Neuen Mitarbeiter hinzufügen", true);
	    addDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    JTextField nameField = new JTextField(20);
	    JTextField surnameField = new JTextField(20);

	    // Name
	    addDialog.add(new JLabel("Vorname:"), gbc);
	    gbc.gridx++;
	    addDialog.add(nameField, gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Nachname
	    addDialog.add(new JLabel("Nachname:"), gbc);
	    gbc.gridx++;
	    addDialog.add(surnameField, gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;
	    
	    // Liste der Kompetenzen
	    gbc.gridx = 0;
	    gbc.gridy++;
	    addDialog.add(new JLabel("Kompetenzen:"), gbc);
	    gbc.gridx++;

	    // Verwenden Sie das DefaultListModel für die Kompetenzen
	    DefaultListModel<Competence> tempCompetenciesModel = new DefaultListModel<>();
	    JList<Competence> competenciesList = new JList<>(tempCompetenciesModel);
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    addDialog.add(competenciesScrollPane, gbc);

	    // Button zum Hinzufügen von Kompetenzen
	    JButton addCompetenceButton = new JButton("+");
	    addCompetenceButton.addActionListener(e -> openCompetenceSelectionDialog(tempCompetenciesModel));
	    gbc.gridx++;
	    addDialog.add(addCompetenceButton, gbc);

	    // Hinzufügen-Button
	    gbc.gridx = 0;
	    gbc.gridy++;
	    gbc.gridwidth = 2; // Über zwei Spalten
	    JButton addButton = new JButton("Hinzufügen");
	    addButton.addActionListener(e -> {
	        try {
	            String newName = nameField.getText().trim();
	            String newSurname = surnameField.getText().trim();
	            if (newName.isEmpty() || newSurname.isEmpty()) {
	                throw new IllegalArgumentException("Name und Nachname dürfen nicht leer sein.");
	            }

	            Employee newEmployee = new Employee(newName, newSurname);
	            for (int i = 0; i < tempCompetenciesModel.size(); i++) {
	                newEmployee.addCompetence(tempCompetenciesModel.get(i));
	            }
	            // Mitarbeiter zur internen Liste und zum Model der JList hinzufügen
	            employees.add(newEmployee);
	            ((DefaultListModel<Employee>)employeeList.getModel()).addElement(newEmployee);

	            addDialog.dispose();
	        } catch (IllegalArgumentException ex) {
	            JOptionPane.showMessageDialog(addDialog, ex.getMessage(), "Eingabefehler", JOptionPane.ERROR_MESSAGE);
	        }
	    });

	    gbc.gridx = 1;
	    gbc.gridy++;
	    addDialog.add(addButton, gbc);

	    addDialog.pack();
	    addDialog.setLocationRelativeTo(frame);
	    addDialog.setVisible(true);		
	}

	/**
	 * Entfernt einen ausgewählten Mitarbeiter aus der internen Liste und dem Model der JList.
	 * @param selectedEmployee Der zu entfernende Mitarbeiter.
	 */
	private void removeEmployee(Employee selectedEmployee) {
	    // Entfernen des Mitarbeiters aus der internen Liste
	    employees.remove(selectedEmployee);

	    // Entfernen des Mitarbeiters aus dem DefaultListModel der JList
	    DefaultListModel<Employee> model = (DefaultListModel<Employee>) employeeList.getModel();
	    model.removeElement(selectedEmployee);
	}
	
	/**
	 * Öffnet ein Dialogfenster, um die Details eines ausgewählten Mitarbeiters zu bearbeiten.
	 * Benutzer können den Namen, Nachnamen und die Kompetenzen des Mitarbeiters ändern.
	 * @param selectedEmployee Der zu bearbeitende Mitarbeiter.
	 */
	private void editEmployeeDetails(Employee selectedEmployee) {
		JDialog editDialog = new JDialog(frame, "Mitarbeiter bearbeiten", true);
	    editDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Eingabefelder für den Namen und Nachnamen des Mitarbeiters
	    JTextField nameField = new JTextField(selectedEmployee.getName(), 20);
	    JTextField surnameField = new JTextField(selectedEmployee.getSurname(), 20);

	    // Name
	    editDialog.add(new JLabel("Name:"), gbc);
	    gbc.gridx++;
	    editDialog.add(nameField, gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Nachname
	    editDialog.add(new JLabel("Nachname:"), gbc);
	    gbc.gridx++;
	    editDialog.add(surnameField, gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;
	    
	    // Liste der Kompetenzen und Buttons zum Hinzufügen/Entfernen
	    editDialog.add(new JLabel("Kompetenzen:"), gbc);
	    gbc.gridx++;
	    DefaultListModel<Competence> competenciesModel = new DefaultListModel<>();
	    for (Competence competence : selectedEmployee.getCompetencies()) {
	        competenciesModel.addElement(competence);
	    }
	    JList<Competence> competenciesList = new JList<>(competenciesModel);
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    editDialog.add(competenciesScrollPane, gbc);

	    // Button zum Hinzufügen von Kompetenzen
	    JButton addCompetenceButton = new JButton("+");
	    addCompetenceButton.addActionListener(e -> openCompetenceSelectionDialog(selectedEmployee, competenciesList, competenciesModel));
	    gbc.gridx++;
	    editDialog.add(addCompetenceButton, gbc);

	    // Button zum Entfernen von Kompetenzen
	    JButton removeCompetenceButton = new JButton("-");
	    removeCompetenceButton.addActionListener(e -> {
	        List<Competence> selectedCompetencies = competenciesList.getSelectedValuesList();
	        for (Competence competence : selectedCompetencies) {
	            selectedEmployee.removeCompetence(competence);
	            competenciesModel.removeElement(competence);
	        }
	    });
	    gbc.gridx++;
	    editDialog.add(removeCompetenceButton, gbc);
	        
	    // Speichern-Button
	    JButton saveButton = new JButton("Speichern");
	    saveButton.addActionListener(e -> {
	        // Validierung der Eingaben
	    	try {
	        	String newName = nameField.getText().trim();
	            String newSurname = surnameField.getText().trim();
	            if (newName.isEmpty() || newSurname.isEmpty()) {
	                throw new IllegalArgumentException("Name und Nachname dürfen nicht leer sein.");
	            }
	            // Aktualisierung der Mitarbeiterdetails
	            selectedEmployee.setName(newName);
	            selectedEmployee.setSurname(newSurname);
	            editDialog.dispose();
	        } catch (IllegalArgumentException ex) {
	            JOptionPane.showMessageDialog(editDialog, ex.getMessage(), "Eingabefehler", JOptionPane.ERROR_MESSAGE);
	        }
	    });

	    gbc.gridx = 1;
	    gbc.gridy++;
	    editDialog.add(saveButton, gbc);

	    editDialog.pack();
	    editDialog.setLocationRelativeTo(frame);
	    editDialog.setVisible(true);
	}
	
	/**
	 * Zeigt ein Dialogfenster mit den Details eines ausgewählten Mitarbeiters an.
	 * Dies beinhaltet den Namen, Nachnamen und die Liste der Kompetenzen des Mitarbeiters.
	 * @param selectedEmployee Der Mitarbeiter, dessen Details angezeigt werden sollen.
	 */
	private void showEmployeeDetails(Employee selectedEmployee) {
		JDialog detailsDialog = new JDialog(frame, "Mitarbeiter Details", true);
	    detailsDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Name des Mitarbeiters
	    detailsDialog.add(new JLabel("Vorname:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(selectedEmployee.getName()), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Nachname des Mitarbeiters
	    detailsDialog.add(new JLabel("Nachname:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(selectedEmployee.getSurname()), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Liste der Kompetenzen des Mitarbeiters
	    detailsDialog.add(new JLabel("Kompetenzen:"), gbc);
	    JList<Competence> competenciesList = new JList<>(new Vector<>(selectedEmployee.getCompetencies()));
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    gbc.gridx++;
	    detailsDialog.add(competenciesScrollPane, gbc);
	    // Dialogfenster vorbereiten und anzeigen
	    detailsDialog.pack();
	    detailsDialog.setLocationRelativeTo(frame);
	    detailsDialog.setVisible(true);
	}

	/**
	 * Entfernt eine ausgewählte User Story sowohl aus der internen Liste der User Stories 
	 * als auch aus dem DefaultListModel der JList.
	 * @param selectedStory Die zu entfernende User Story.
	 */
	private void removeUserStory(UserStory selectedStory) {
	    // Entfernen der User Story aus der internen Liste der User Stories
	    userStories.remove(selectedStory);

	    // Entfernen der User Story aus dem DefaultListModel der JList
	    DefaultListModel<UserStory> model = (DefaultListModel<UserStory>) userStoryList.getModel();
	    model.removeElement(selectedStory);
	}

	/**
	 * Öffnet ein Dialogfenster, um die Details einer ausgewählten User Story zu bearbeiten.
	 * Benutzer können Eigenschaften wie Titel, Beschreibung, Nutzwert, Komplexität und Risiken ändern.
	 * @param story Die zu bearbeitende User Story.
	 */
	private void editUserStoryDetails(UserStory story) {
	    JDialog editDialog = new JDialog(frame, "UserStory bearbeiten", true);
	    editDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Eingabefelder für die Eigenschaften der User Story
	    JTextField titleField = new JTextField(story.getTitle(), 20);
	    JTextField descriptionField = new JTextField(story.getDescription(), 20);
	    JTextField utilityField = new JTextField(String.valueOf(story.getUtility()), 5);
	    JTextField complexityField = new JTextField(String.valueOf(story.getComplexity()), 5);
	    JTextField criticalRiskField = new JTextField(String.format("%.2f", story.getCritical_risk()), 5);
	    JTextField uncertaintyRiskField = new JTextField(String.format("%.2f", story.getUncertainty_risk()), 5);

	    // Hinzufügen der Komponenten zum Dialogfenster
	    addDialogComponents(editDialog, gbc, "Titel", titleField);
	    addDialogComponents(editDialog, gbc, "Beschreibung", descriptionField);
	    addDialogComponents(editDialog, gbc, "Nutzwert (Utility)", utilityField);
	    addDialogComponents(editDialog, gbc, "Komplexität (Story Points)", complexityField);
	    addDialogComponents(editDialog, gbc, "Kritisches Risiko", criticalRiskField);
	    addDialogComponents(editDialog, gbc, "Unsicherheitsrisiko", uncertaintyRiskField);

	    // Liste der erforderlichen Kompetenzen und Buttons zum Hinzufügen/Entfernen
	    gbc.gridx = 0;
	    gbc.gridy++;
	    editDialog.add(new JLabel("Erforderliche Kompetenzen:"), gbc);
	    gbc.gridx++;

	    DefaultListModel<Competence> competenciesModel = new DefaultListModel<>();
	    for (Competence competence : story.getRequiredCompetencies()) {
	        competenciesModel.addElement(competence);
	    }
	    JList<Competence> competenciesList = new JList<>(competenciesModel);
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    editDialog.add(competenciesScrollPane, gbc);

	    JButton addCompetenceButton = new JButton("+");
	    addCompetenceButton.addActionListener(e -> openCompetenceSelectionDialog(story, competenciesList, competenciesModel));
	    gbc.gridx++;
	    editDialog.add(addCompetenceButton, gbc);

	    JButton removeCompetenceButton = new JButton("-");
	    removeCompetenceButton.addActionListener(e -> {
	        List<Competence> selectedCompetencies = competenciesList.getSelectedValuesList();
	        for (Competence competence : selectedCompetencies) {
	            story.removeRequiredCompetence(competence);
	            competenciesModel.removeElement(competence);
	        }
	    });
	    gbc.gridx++;
	    editDialog.add(removeCompetenceButton, gbc);

	    // Speichern-Button zum Bestätigen der Änderungen
	    JButton saveButton = new JButton("Speichern");
	    saveButton.addActionListener(e -> {
	        try {
	            String newTitle = titleField.getText().trim();
	            String newDescription = descriptionField.getText().trim();
	            int newUtility = Integer.parseInt(utilityField.getText().trim());
	            int newComplexity = Integer.parseInt(complexityField.getText().trim());
	            double newCriticalRisk = Double.parseDouble(criticalRiskField.getText().trim().replace(',', '.'));
	            double newUncertaintyRisk = Double.parseDouble(uncertaintyRiskField.getText().trim().replace(',', '.'));

	            // Überprüfung, ob Eingaben leer sind
	            if (newTitle.isEmpty() || newDescription.isEmpty()) {
	                throw new IllegalArgumentException("Titel und Beschreibung dürfen nicht leer sein.");
	            }

	            // Aktualisierung der User Story Eigenschaften
	            story.setTitle(newTitle);
	            story.setDescription(newDescription);
	            story.setUtility(newUtility);
	            story.setComplexity(newComplexity);
	            story.setCritical_risk(newCriticalRisk);
	            story.setUncertainty_risk(newUncertaintyRisk);

	            editDialog.dispose();
	        } catch (IllegalArgumentException ex) {
	            JOptionPane.showMessageDialog(editDialog, "Bitte geben Sie gültige Werte ein. " + ex.getMessage(), "Eingabefehler", JOptionPane.ERROR_MESSAGE);
	        }
	    });

	    gbc.gridx = 1;
	    gbc.gridy++;
	    editDialog.add(saveButton, gbc);

	    editDialog.pack();
	    editDialog.setLocationRelativeTo(frame);
	    editDialog.setVisible(true);
	}

	/**
	 * Hilfsmethode zum Hinzufügen von Komponenten zum Dialogfenster.
	 */
	private void addDialogComponents(JDialog dialog, GridBagConstraints gbc, String label, Component component) {
	    dialog.add(new JLabel(label + ":"), gbc);
	    gbc.gridx++;
	    dialog.add(component, gbc);
	    gbc.gridx = 0;
	    gbc.gridy++;
	}
	
	/**
	 * Öffnet ein Dialogfenster, um Kompetenzen aus einer Liste auszuwählen und dem übergebenen Objekt hinzuzufügen.
	 * Das Objekt kann entweder eine User Story oder ein Mitarbeiter sein.
	 * @param object Das Objekt (User Story oder Mitarbeiter), dem Kompetenzen hinzugefügt werden sollen.
	 * @param competenciesList Die JList, die die bereits zugewiesenen Kompetenzen anzeigt.
	 * @param competenciesModel Das DefaultListModel, das die Kompetenzen für das übergebene Objekt verwaltet.
	 * @param <T> Der generische Typ des Objekts.
	 */
	private <T> void openCompetenceSelectionDialog(T object, JList<Competence> competenciesList, DefaultListModel<Competence> competenciesModel) {
	    JDialog selectionDialog = new JDialog(frame, "Kompetenzen auswählen", true);
	    selectionDialog.setLayout(new BorderLayout());

	    // Liste aller verfügbaren Kompetenzen erstellen und anzeigen
	    JList<Competence> allCompetenciesList = new JList<>(new Vector<>(allCompetencies));
	    allCompetenciesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
	    JScrollPane scrollPane = new JScrollPane(allCompetenciesList);
	    selectionDialog.add(scrollPane, BorderLayout.CENTER);

	    // Hinzufügen-Button, um ausgewählte Kompetenzen dem Objekt hinzuzufügen
	    JButton addButton = new JButton("Hinzufügen");
	    addButton.addActionListener(e -> {
	        List<Competence> selectedCompetencies = allCompetenciesList.getSelectedValuesList();
	        for (Competence competence : selectedCompetencies) {
	            if (!competenciesModel.contains(competence)) {
	                competenciesModel.addElement(competence);

	                // Kompetenzen zum Objekt hinzufügen, abhängig vom Typ
	                if (object instanceof UserStory) {
	                    ((UserStory) object).addRequiredCompetence(competence);
	                } else if (object instanceof Employee) {
	                    ((Employee) object).addCompetence(competence);
	                }
	            }
	        }
	        selectionDialog.dispose();
	    });

	    selectionDialog.add(addButton, BorderLayout.SOUTH);

	    selectionDialog.pack();
	    selectionDialog.setLocationRelativeTo(frame);
	    selectionDialog.setVisible(true);
	}
	
	/**
	 * Öffnet ein Dialogfenster, um Kompetenzen aus einer Gesamtliste auszuwählen und dem übergebenen DefaultListModel hinzuzufügen.
	 * @param competenciesModel Das DefaultListModel, das die ausgewählten Kompetenzen verwaltet.
	 */
	private void openCompetenceSelectionDialog(DefaultListModel<Competence> competenciesModel) {
	    JDialog competenceDialog = new JDialog(frame, "Kompetenzen auswählen", true);
	    competenceDialog.setLayout(new BorderLayout());

	    // Liste aller verfügbaren Kompetenzen erstellen und anzeigen
	    JList<Competence> allCompetencesList = new JList<>(new Vector<>(allCompetencies));
	    allCompetencesList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
	    JScrollPane scrollPane = new JScrollPane(allCompetencesList);
	    competenceDialog.add(scrollPane, BorderLayout.CENTER);

	    // Button zum Hinzufügen ausgewählter Kompetenzen zum DefaultListModel
	    JButton addButton = new JButton("Hinzufügen");
	    addButton.addActionListener(e -> {
	        List<Competence> selectedCompetences = allCompetencesList.getSelectedValuesList();
	        for (Competence competence : selectedCompetences) {
	            if (!competenciesModel.contains(competence)) {
	                competenciesModel.addElement(competence);
	            }
	        }
	        competenceDialog.dispose();
	    });

	    competenceDialog.add(addButton, BorderLayout.SOUTH);
	    competenceDialog.pack();
	    competenceDialog.setLocationRelativeTo(frame);
	    competenceDialog.setVisible(true);
	}
	
	/**
	 * Zeigt ein Dialogfenster mit detaillierten Informationen über eine ausgewählte User Story.
	 * Enthält Titel, Beschreibung, Nutzwert, Komplexität, Risiken und erforderliche Kompetenzen.
	 * @param story Die User Story, deren Details angezeigt werden sollen.
	 */
	private void showUserStoryDetails(UserStory story) {
	    JDialog detailsDialog = new JDialog(frame, "UserStory Details", true);
	    detailsDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;

	    // Anzeige des Titels der User Story
	    detailsDialog.add(new JLabel("Titel:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(story.getTitle()), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige der Beschreibung der User Story
	    detailsDialog.add(new JLabel("Beschreibung:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(story.getDescription()), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige des Nutzwerts (Utility)
	    detailsDialog.add(new JLabel("Nutzwert (Utility):"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(String.valueOf(story.getUtility())), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige der Komplexität (Story Points)
	    detailsDialog.add(new JLabel("Komplexität (Story Points):"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(String.valueOf(story.getComplexity())), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige des kritischen Risikos
	    detailsDialog.add(new JLabel("Kritisches Risiko:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(String.format("%.2f", story.getCritical_risk())), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige des Unsicherheitsrisikos
	    detailsDialog.add(new JLabel("Unsicherheitsrisiko:"), gbc);
	    gbc.gridx++;
	    detailsDialog.add(new JLabel(String.format("%.2f", story.getUncertainty_risk())), gbc);

	    gbc.gridx = 0;
	    gbc.gridy++;

	    // Anzeige der Liste der erforderlichen Kompetenzen
	    detailsDialog.add(new JLabel("Erforderliche Kompetenzen:"), gbc);
	    JList<Competence> competenciesList = new JList<>(new Vector<>(story.getRequiredCompetencies()));
	    competenciesList.setVisibleRowCount(5);
	    competenciesList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenciesScrollPane = new JScrollPane(competenciesList);
	    gbc.gridx++;
	    detailsDialog.add(competenciesScrollPane, gbc);

	    // Dialogfenster vorbereiten und anzeigen
	    detailsDialog.pack();
	    detailsDialog.setLocationRelativeTo(frame);
	    detailsDialog.setVisible(true);
	}

	/**
	 * Öffnet einen Dialog zur Auswahl einer Datei, die Mitarbeiterdaten enthält.
	 * Nach der Auswahl wird die Datei eingelesen und die Mitarbeiterdaten geladen.
	 */
	private void openEmployeeDialog() {
		JFileChooser fileChooser = new JFileChooser();
	    fileChooser.setDialogTitle("Mitarbeiter laden");
	    int result = fileChooser.showOpenDialog(frame);
	    if (result == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = fileChooser.getSelectedFile();
	        // Methode zum Einlesen und Parsen der Datei aufrufen
	        loadEmployeesFromFile(selectedFile);
	    }
	}

	/**
	 * Liest die Mitarbeiterdaten aus einer Datei und aktualisiert die interne Liste und das JList-Modell.
	 * @param file Die Datei, aus der die Mitarbeiterdaten geladen werden sollen.
	 */
	private void loadEmployeesFromFile(File file) {
		Gson gson = new GsonBuilder()
		        .registerTypeAdapter(Employee.class, new EmployeeTypeAdapter(allCompetencies))
		        .create();
	    Type employeeListType = new TypeToken<List<Employee>>(){}.getType();

	    try (FileReader reader = new FileReader(file)) {
	        List<Employee> employeesFromFile = gson.fromJson(reader, employeeListType);

	        // Aktualisieren der internen Liste
	        employees.clear();
	        employees.addAll(employeesFromFile);

	        // Aktualisieren des Models der JList
	        mitarbeiterModel.clear();
	        employees.forEach(mitarbeiterModel::addElement);
	    } catch (IOException e) {
	        e.printStackTrace();
	        // Fehlerbehandlung
	        JOptionPane.showMessageDialog(frame, "Fehler beim Laden der Mitarbeiter: " + e.getMessage(), "Ladefehler", JOptionPane.ERROR_MESSAGE);
	    }
	}

	/**
	 * Öffnet einen Dialog zur Auswahl einer Datei, die User Story Daten für das Product Backlog enthält.
	 * Nach der Auswahl wird die Datei eingelesen und die User Stories geladen.
	 */
	private void openProductBacklogDialog() {
		JFileChooser fileChooser = new JFileChooser();
	    fileChooser.setDialogTitle("Product Backlog laden");
	    int result = fileChooser.showOpenDialog(frame);
	    if (result == JFileChooser.APPROVE_OPTION) {
	        File selectedFile = fileChooser.getSelectedFile();
	        // Methode zum Einlesen und Parsen der Datei aufrufen
	        loadUserStoriesFromFile(selectedFile);
	    }
	}

	/**
	 * Liest die User Story Daten aus einer Datei und aktualisiert die interne Liste und das JList-Modell.
	 * @param file Die Datei, aus der die User Story Daten geladen werden sollen.
	 */
	private void loadUserStoriesFromFile(File file) {
		Gson gson = new GsonBuilder()
		        .registerTypeAdapter(UserStory.class, new UserStoryTypeAdapter(allCompetencies))
		        .create();
	    Type userStoryListType = new TypeToken<List<UserStory>>(){}.getType();

	    try (FileReader reader = new FileReader(file)) {
	        List<UserStory> userStoriesFromFile = gson.fromJson(reader, userStoryListType);

	        // Aktualisieren der internen Liste
	        userStories.clear();
	        userStories.addAll(userStoriesFromFile);

	        // Aktualisieren des Models der JList
	        backlogModel.clear();
	        userStories.forEach(backlogModel::addElement);
	        // Optional: Benachrichtigen der UI-Komponenten über die Datenänderung
	    
	    } catch (IOException e) {
	        e.printStackTrace();
	        // Fehlerbehandlung, z.B. Dialog mit Fehlermeldung anzeigen
	        JOptionPane.showMessageDialog(frame, "Fehler beim Laden des Product Backlogs: " + e.getMessage(), "Ladefehler", JOptionPane.ERROR_MESSAGE);
	    }
	}

	/**
	 * Öffnet ein Dialogfenster zur Verwaltung der Kompetenzen.
	 * Benutzer können Kompetenzen hinzufügen, entfernen und die Liste der Kompetenzen aktualisieren.
	 */
	private void openCompetenceDialog() {
		// Dialog erstellen
	    JDialog competenceDialog = new JDialog(frame, "Kompetenzen bearbeiten", true);
	    competenceDialog.setLayout(new BorderLayout());

	    // JList für die Anzeige der Kompetenzen
	    JList<Competence> competenceList = new JList<>(new Vector<>(allCompetencies));
	    competenceList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    JScrollPane competenceScrollPane = new JScrollPane(competenceList);

	    // Button Panel
	    JPanel buttonPanel = new JPanel();
	    JButton addButton = new JButton("Hinzufügen");
	    JButton removeButton = new JButton("Entfernen");
	    JButton closeButton = new JButton("Aktualisieren");

	    // Aufruf der Methode zum hinzufügen
	    addButton.addActionListener(e -> addCompetence());
	    
	    // Aufruf der Methode zum entfernen
	    removeButton.addActionListener(e -> {
	    	Competence selectedCompetence = competenceList.getSelectedValue();
	    	if (selectedCompetence != null) {
	    		removeCompetence(selectedCompetence);
	    	}
	    });
	    
	    // Aufruf für die aktualisierung
	    closeButton.addActionListener(e -> {
	    	competenceDialog.dispose();
	    	openCompetenceDialog();
	    });
	    
	    buttonPanel.add(addButton);
	    buttonPanel.add(removeButton);
	    buttonPanel.add(closeButton);

	    // Komponenten zum Dialog hinzufügen
	    competenceDialog.add(competenceScrollPane, BorderLayout.CENTER);
	    competenceDialog.add(buttonPanel, BorderLayout.SOUTH);

	    // Dialogeinstellungen
	    competenceDialog.pack();
	    competenceDialog.setLocationRelativeTo(frame);
	    competenceDialog.setVisible(true);
	}

	/**
	 * Entfernt eine ausgewählte Kompetenz aus der Gesamtliste der Kompetenzen und dem JList-Modell.
	 * @param selectedCompetence Die zu entfernende Kompetenz.
	 */
	private void removeCompetence(Competence selectedCompetence) {
		allCompetencies.remove(selectedCompetence);
		// Entfernen aus dem DefaultListModel der JList
	    DefaultListModel<Competence> model = (DefaultListModel<Competence>) competenceList.getModel();
	    model.removeElement(selectedCompetence);
	}

	/**
	 * Öffnet ein Dialogfenster, um eine neue Kompetenz hinzuzufügen.
	 * Benutzer können den Namen der Kompetenz eingeben und diese zur Liste hinzufügen.
	 */
	private void addCompetence() {
		JDialog addDialog = new JDialog(frame, "Neue Kompetenz hinzufügen", true);
	    addDialog.setLayout(new GridBagLayout());
	    GridBagConstraints gbc = new GridBagConstraints();
	    gbc.gridx = 0;
	    gbc.gridy = 0;
	    gbc.anchor = GridBagConstraints.WEST;
	    gbc.insets = new Insets(5, 5, 5, 5);

	    // Eingabefeld für den Namen der Kompetenz
	    JTextField competenceNameField = new JTextField(20);

	    // Label und Eingabefeld zum Dialog hinzufügen
	    addDialog.add(new JLabel("Name der Kompetenz:"), gbc);
	    gbc.gridx++;
	    addDialog.add(competenceNameField, gbc);

	    // Speichern-Button mit Logik zum Hinzufügen der neuen Kompetenz
	    JButton saveButton = new JButton("Speichern");
	    saveButton.addActionListener(e -> {
	    	try {
	            String competenceName = competenceNameField.getText().trim();
	            if (competenceName.isEmpty()) {
	                throw new IllegalArgumentException("Die Kompetenz darf nicht leer sein.");
	            }
	            Competence newCompetence = new Competence(competenceName);
	            allCompetencies.add(newCompetence);
	            ((DefaultListModel<Competence>)competenceList.getModel()).addElement(newCompetence);

	            addDialog.dispose();
	        } catch (IllegalArgumentException ex) {
	            JOptionPane.showMessageDialog(addDialog, ex.getMessage(), "Eingabefehler", JOptionPane.ERROR_MESSAGE);
	        }
	    });

	    gbc.gridx = 0;
	    gbc.gridy++;
	    gbc.gridwidth = 2;
	    addDialog.add(saveButton, gbc);

	    // Dialogeinstellungen
	    addDialog.pack();
	    addDialog.setLocationRelativeTo(frame);
	    addDialog.setVisible(true);
	}

	/**
	 * Öffnet ein Dialogfenster zur Einstellung von Berechnungsvariablen für die Multi-Sprint-Planung 
	 * und die Monte-Carlo-Simulation.
	 */
	private void openSettingsDialog() {
		// Dialogfenster erstellen
	    JDialog settingsDialog = new JDialog(frame, "Berechnungsvariablen", true);
	    settingsDialog.setLayout(new BoxLayout(settingsDialog.getContentPane(), BoxLayout.Y_AXIS));
	    
	    // Panel für Multi-Sprint-Planung Einstellungen
	    JPanel planningPanel = new JPanel(new GridLayout(0, 2));
	    planningPanel.setBorder(BorderFactory.createTitledBorder("Multi-Sprint-Planung"));

	    // Eingabefelder für Multi-Sprint-Planung
	    planningPanel.add(new JLabel("Sprintkapazität:"));
	    JTextField sprintCapacityField = new JTextField(String.valueOf(sprintCapacity));
	    planningPanel.add(sprintCapacityField);

	    planningPanel.add(new JLabel("Sprintzeit:"));
	    JTextField sprintTimeField = new JTextField(String.valueOf(sprintTime));
	    planningPanel.add(sprintTimeField);

	    settingsDialog.add(planningPanel);

	    // Panel für Monte-Carlo-Simulation Einstellungen
	    JPanel simulationPanel = new JPanel(new GridLayout(0, 2));
	    simulationPanel.setBorder(BorderFactory.createTitledBorder("Monte-Carlo-Simulation"));
	    
	    // Eingabefelder für Monte-Carlo-Simulation
	    simulationPanel.add(new JLabel("Anzahl der Simulationen:"));
	    JTextField simulationsField = new JTextField(String.valueOf(simulations));
	    simulationPanel.add(simulationsField);

	    simulationPanel.add(new JLabel("Negative Änderung der Story Points:"));
	    JTextField minChangeField = new JTextField(String.valueOf(minChange));
	    simulationPanel.add(minChangeField);

	    simulationPanel.add(new JLabel("Positive Änderung der Story Points:"));
	    JTextField maxChangeField = new JTextField(String.valueOf(maxChange));
	    simulationPanel.add(maxChangeField);

	    simulationPanel.add(new JLabel("Maximale Anzahl der neuen User Stories:"));
	    JTextField maxNewUserStoriesField = new JTextField(String.valueOf(maxNewUserStories));
	    simulationPanel.add(maxNewUserStoriesField);

	    simulationPanel.add(new JLabel("Minimaler Wert bei neuer User Story (Story Points):"));
	    JTextField minNewField = new JTextField(String.valueOf(minNew));
	    simulationPanel.add(minNewField);

	    simulationPanel.add(new JLabel("Maximaler Wert bei neuer Story (Story Points):"));
	    JTextField maxNewField = new JTextField(String.valueOf(maxNew));
	    simulationPanel.add(maxNewField);

	    settingsDialog.add(simulationPanel);
	    
	    // Speichern-Button
	    JButton saveButton = new JButton("Speichern");
	    saveButton.addActionListener(e -> {
	        // Werte aus den Eingabefeldern übernehmen
	        sprintCapacity = Integer.parseInt(sprintCapacityField.getText());
	        sprintTime = Integer.parseInt(sprintTimeField.getText());
	        simulations = Integer.parseInt(simulationsField.getText());
	        minChange = Integer.parseInt(minChangeField.getText());
	        maxChange = Integer.parseInt(maxChangeField.getText());
	        maxNewUserStories = Integer.parseInt(maxNewUserStoriesField.getText());
	        minNew = Integer.parseInt(minNewField.getText());
	        maxNew = Integer.parseInt(maxNewField.getText());
	        settingsDialog.dispose();
	    });
	    
	    JPanel buttonPanel = new JPanel();
	    buttonPanel.add(saveButton);
	    settingsDialog.add(buttonPanel);

	    // Dialogfenster anzeigen
	    settingsDialog.pack();
	    settingsDialog.setVisible(true);
	}

	/**
	 * Erstellt ein Dataset für ein Burn-Down-Chart basierend auf einer Liste von Sprints und der Sprintzeit.
	 * @param sprints Die Liste der Sprints, die in das Dataset einbezogen werden sollen.
	 * @param sprintTime Die Dauer eines Sprints in Wochen.
	 * @return Ein DefaultCategoryDataset, das die Daten für das Burn-Down-Chart enthält.
	 */
	private DefaultCategoryDataset createBurnDownData(List<Sprint> sprints, int sprintTime) {
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        
	    // Annahme: totalStoryPoints berechnet die Summe aller Story Points zu Beginn
	    int totalStoryPoints = sprints.stream()
	                                   .mapToInt(Sprint::getCurrentStoryPoints) // Angenommen, getInitialStoryPoints gibt die initialen Story Points für jeden Sprint zurück
	                                   .sum();
	    int remainingStoryPoints = totalStoryPoints;

	    // Berechnung für die ideale Linie
	    double idealPointsPerWeek = (double) totalStoryPoints / sprints.size();

	    // Hinzufügen des Startpunkts für die aktuelle Linie und die ideale Linie
	    dataset.addValue(remainingStoryPoints, "Projekt-Linie", "0 Wochen");
	    dataset.addValue(totalStoryPoints, "Ideal-Linie", "0 Wochen");

	    for (int i = 0; i < sprints.size(); i++) {
	        // Aktualisiere die verbleibenden Story Points basierend auf dem tatsächlichen Fortschritt
	        remainingStoryPoints -= sprints.get(i).getCurrentStoryPoints(); // Annahme: getCurrentStoryPoints gibt die in diesem Sprint abgearbeiteten Story Points zurück
	        dataset.addValue(remainingStoryPoints, "Projekt-Linie", (i + 1) * sprintTime + " Wochen");

	        // Berechne und füge den nächsten Punkt für die ideale Linie hinzu
	        double idealRemaining = Math.max(totalStoryPoints - ((i + 1) * idealPointsPerWeek), 0);
	        dataset.addValue(idealRemaining, "Ideal-Linie", (i + 1) * sprintTime + " Wochen");
	    }

	    return dataset;
	}

	/**
	 * Aktualisiert eine Tabelle mit den Daten eines bestimmten Sprints.
	 * Für jede User Story im Sprint werden der Titel und der zugeordnete Mitarbeiter angezeigt.
	 * Am Ende der Tabelle wird eine Zusammenfassung des Sprints mit Nutzen und Komplexität hinzugefügt.
	 * @param sprint Der Sprint, dessen Daten in der Tabelle angezeigt werden sollen.
	 */
	private void updateTableWithSprintData(Sprint sprint) {
        DefaultTableModel model = (DefaultTableModel) sprintTable.getModel();
        model.setRowCount(0); // Leert die Tabelle
        
        // Variablen für die Berechnung von Nutzen und Komplexität des Sprints
        int sprintUtility = 0;
    	int sprintComplexity = 0;
    	// Hinzufügen der User Stories zum Modell
        for (UserStory us : sprint.getUserStories()) {
            model.addRow(new Object[]{us.getTitle(), us.getEmployee().getName()});
            sprintUtility += us.getUtility() * us.getCritical_risk();
    		sprintComplexity += us.getComplexity() * us.getUncertainty_risk();
        }
        
        // Leere Zeile als Trennung
        model.addRow(new Object[]{" "});
        
        // Zeile für den aktuellen Sprint hinzufügen
        model.addRow(new Object[]{"Aktueller Sprint: " + (currentSprintIndex + 1), ""});
        model.addRow(new Object[]{"Sprint Nutzen (Utility): " + (sprintUtility), ""});
        model.addRow(new Object[]{"Sprint Komplexität (Story Points): " + (sprintComplexity), ""});
    }
	/**
	 * Aktualisiert die Labels mit den Gesamtergebnissen der Multi-Sprint-Planung.
	 * Es werden die Anzahl der Sprints, der gesamte Nutzen, die gesamte Komplexität und die gesamte benötigte Zeit angezeigt.
	 * @param sprintNumber Die Gesamtanzahl der Sprints.
	 * @param totalUtility Der gesamte Nutzen (Utility) über alle Sprints.
	 * @param totalComplexity Die gesamte Komplexität (Story Points) über alle Sprints.
	 * @param totalTimeNeeded Die gesamte benötigte Zeit für alle Sprints in Wochen.
	 */
    public void updateTotalResults(int sprintNumber, int totalUtility, int totalComplexity, int totalTimeNeeded) {
        int sprintSize = sprintNumber - 1;
    	sprintNumberLabel.setText("Anzahl der Sprints: " + sprintSize);
    	totalUtilityLabel.setText("Gesamter Nutzen (Utility) über alle Sprints: " + totalUtility);
        totalComplexityLabel.setText("Gesamte Komplexität (StoryPoints) über alle Sprints: " + totalComplexity);
        totalTimeLabel.setText("Gesamt benötigte Zeit (in Wochen): " + totalTimeNeeded);
    }
}
