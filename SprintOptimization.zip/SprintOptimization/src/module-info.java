/**
 * 
 */
/**
 * 
 */
module SprintOptimization {
	requires cplex;
	requires java.desktop;
	requires org.jfree.jfreechart;
	requires com.google.gson;
}