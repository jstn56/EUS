package main;

import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;

import model.Competence;
import model.CompetenceManager;
import model.Employee;
import model.UserStory;
import ui.ScrumApp;
import ilog.concert.IloException;

// Hauptklasse des Programms
public class Main {

    public static void main(String[] args) throws IloException {
        // Initialisierung der Kompetenzen und Ausgabe
        List<Competence> allCompetencies = initializeCompetencies();
        // Initialisierung der Mitarbeiter und Ausgabe
        List<Employee> employees = initializeAndPrintEmployees();
        // Initialisierung der User Stories und Ausgabe
        List<UserStory> userStories = initializeAndPrintUserStories();
        // Start der UI
        SwingUtilities.invokeLater(() -> new ScrumApp(userStories, employees, allCompetencies));
    }
    
    // Methode zur Initialisierung der Kompetenzen
    private static List<Competence> initializeCompetencies() {
        System.out.println("Hallo World!");
        // Initialisierung der verfügbaren Kompetenzen
        CompetenceManager.initializeCompetencies();
        
        // Alle verfügbaren Kompetenzen abrufen und ausgeben
        List<Competence> allCompetencies = Competence.getAllCompetencies();
        
        System.out.println("Folgende Kompetenzen stehen zur Verfügung:");
        for (Competence competence : allCompetencies) {
            System.out.println(competence.getName());
        }
        System.out.println("--------------------------------------------------");
        return allCompetencies;
    }
    
    // Methode zur Initialisierung und Ausgabe der Mitarbeiter
    private static List<Employee> initializeAndPrintEmployees() {
        // Liste zur Speicherung der Employee-Objekte erstellen
        List<Employee> employees = new ArrayList<>();
        // Einige Employee-Objekte erstellen
        employees.add(new Employee("John", "D."));
        employees.add(new Employee("Jane", "S."));
        employees.add(new Employee("Alice", "J."));
        employees.add(new Employee("Alex", "O."));
        
        
        // Jedem Mitarbeiter eine Kompetenz zuweisen
        for (int i = 0; i < employees.size(); i++) {
            Employee employee = employees.get(i);
            Competence competence = Competence.getAllCompetencies().get(i % Competence.getAllCompetencies().size());  // Holt eine Kompetenz aus der Liste basierend auf dem Index
            employee.addCompetence(competence);
        }
        Employee employe1 = employees.get(0);      
        employe1.addCompetence(Competence.getAllCompetencies().get(1));
        Employee employe2 = employees.get(1);      
        employe2.addCompetence(Competence.getAllCompetencies().get(0));
        // Namen und Kompetenzen jedes Mitarbeiters ausgeben
        for (Employee employee : employees) {
            System.out.println(employee.toString() + " hat die Kompetenzen: " + employee.getCompetencies().toString());
        }
        System.out.println("--------------------------------------------------");
        return employees;
    }
    
    // Methode zur Initialisierung und Ausgabe der User Stories
    private static List<UserStory> initializeAndPrintUserStories() {
        
        // Liste zur Speicherung der UserStory-Objekte erstellen
        List<UserStory> userStories = new ArrayList<>();
        
        // UserStory-Objekte erstellen und zur Liste hinzufügen
        userStories.add(new UserStory("UserStory 1", "Beschreibung 1", 70, 7, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 2", "Beschreibung 2", 80, 3, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 3", "Beschreibung 3", 60, 6, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 4", "Beschreibung 4", 70, 8 , 1.00, 1.00));
        userStories.add(new UserStory("UserStory 5", "Beschreibung 5", 5, 4, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 6", "Beschreibung 6", 6, 3, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 7", "Beschreibung 7", 50, 5, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 8", "Beschreibung 8", 90, 3, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 9", "Beschreibung 9", 90, 4, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 10", "Beschreibung 10", 90, 6, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 11", "Beschreibung 11", 90, 3, 1.00, 1.00));
        userStories.add(new UserStory("UserStory 12", "Beschreibung 12", 90, 4, 1.00, 1.00));


        // Jeder UserStory eine erforderliche Kompetenz zuweisen
        for (int i = 0; i < userStories.size(); i++) {
            UserStory userStory = userStories.get(i);
            Competence competence = Competence.getAllCompetencies().get(i % Competence.getAllCompetencies().size());  // Holt eine Kompetenz aus der Liste basierend auf dem Index
            userStory.addRequiredCompetence(competence);
        }

        // Alle Werte jeder UserStory ausgeben
        for (UserStory userStory : userStories) {
            System.out.println("ID: " + userStory.getId());
            System.out.println("Titel: " + userStory.getTitle());
            System.out.println("Beschreibung: " + userStory.getDescription());
            System.out.println("Nützlichkeit: " + userStory.getUtility());
            System.out.println("Komplexität: " + userStory.getComplexity());
            System.out.println("Kritisches Risiko: " + userStory.getCritical_risk());
            System.out.println("Unsicherheitsrisiko: " + userStory.getUncertainty_risk());
            System.out.println("Erforderliche Kompetenzen: " + userStory.getRequiredCompetencies());
            System.out.println("--------------------------------------------------");
        }
        return userStories;
    }
}
